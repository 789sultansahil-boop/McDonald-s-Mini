import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { MENU_ITEMS } from "../constants";

// Initialize Gemini
let chatSession: Chat | null = null;

const getSystemInstruction = () => {
  // Fetch latest menu from localStorage synchronously for the prompt context
  // Fallback to MENU_ITEMS constant if storage is empty or error
  let currentMenu = MENU_ITEMS;
  try {
    const stored = localStorage.getItem('mcd_menu_items_butranwali');
    if (stored) {
      currentMenu = JSON.parse(stored);
    }
  } catch (e) {
    // Fallback silently if storage fails
  }

  const menuContext = JSON.stringify(currentMenu.map(item => ({
    name: item.name,
    description: item.description,
    price: item.price,
    tags: item.tags,
    category: item.category
  })));

  return `
    You are a friendly and helpful Crew Member at "McDonald's" in "Butranwali Gujranwala".
    
    Here is our current menu in JSON format:
    ${menuContext}

    Your Rules:
    1. Answer questions ONLY related to the menu, current offers (improvise general McDonald's offers if asked, like Meal deals), or the specific location (Butranwali).
    2. Be cheerful, casual, and use phrases like "I'm lovin' it" or "Happy to help!".
    3. Keep answers concise (under 50 words) unless the user asks for a detailed nutritional breakdown.
    4. If asked about ingredients or allergens, guide them based on the description but recommend they check the official nutrition guide for serious allergies.
    5. Do not hallucinate items not on the menu (e.g., if they ask for a Whopper, politely say that's at Burger King and suggest a Big Mac instead).
  `;
};

export const initializeChat = (reset = false): Chat => {
  if (chatSession && !reset) return chatSession;

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  chatSession = ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: getSystemInstruction(),
      temperature: 0.7,
    }
  });
  
  return chatSession;
};

export const sendMessageToWaiter = async (message: string): Promise<string> => {
  try {
    // Initialize (or reuse) chat. 
    // Note: If menu changes, the page reload usually resets this, 
    // but strictly speaking we might want to reset session if menu updates.
    const chat = initializeChat();
    const result: GenerateContentResponse = await chat.sendMessage({ message });
    return result.text || "Sorry, I missed that. Can you say it again?";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm having a bit of trouble hearing you over the fryer. Please ask again!";
  }
};