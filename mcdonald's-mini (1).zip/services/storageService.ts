
import { Order, OrderStatus, MenuItem, Promotion, LoyaltyUser, SavedFavorite } from '../types';
import { MENU_ITEMS, MOCK_PROMOTIONS } from '../constants';
import { deductInventory, getRequiredIngredients } from './inventoryService';

const MENU_STORAGE_KEY = 'mcd_menu_items_butranwali_v5'; // Bumped version for new items
const ORDER_STORAGE_KEY = 'mcd_orders_butranwali';
const PROMO_STORAGE_KEY = 'mcd_promotions_butranwali';
const LOYALTY_STORAGE_KEY = 'mcd_loyalty_users_butranwali';

// --- Menu Services ---

export const getMenuItems = async (): Promise<MenuItem[]> => {
  try {
    const stored = localStorage.getItem(MENU_STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
    // Initial Load: save constants to storage so we can edit them later
    localStorage.setItem(MENU_STORAGE_KEY, JSON.stringify(MENU_ITEMS));
    return MENU_ITEMS;
  } catch (error) {
    console.error("Error loading menu", error);
    return MENU_ITEMS;
  }
};

export const saveMenuItem = async (item: MenuItem): Promise<void> => {
  const items = await getMenuItems();
  const index = items.findIndex(i => i.id === item.id);
  
  let newItems;
  if (index >= 0) {
    newItems = [...items];
    newItems[index] = item;
  } else {
    newItems = [...items, item];
  }
  
  localStorage.setItem(MENU_STORAGE_KEY, JSON.stringify(newItems));
  // Dispatch event for live updates
  window.dispatchEvent(new Event('menu-updated'));
};

export const deleteMenuItem = async (id: string): Promise<void> => {
  const items = await getMenuItems();
  const newItems = items.filter(i => i.id !== id);
  localStorage.setItem(MENU_STORAGE_KEY, JSON.stringify(newItems));
  window.dispatchEvent(new Event('menu-updated'));
};

// --- Promotion Services ---

export const getPromotions = async (): Promise<Promotion[]> => {
  try {
    const stored = localStorage.getItem(PROMO_STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
    localStorage.setItem(PROMO_STORAGE_KEY, JSON.stringify(MOCK_PROMOTIONS));
    return MOCK_PROMOTIONS;
  } catch (error) {
    return MOCK_PROMOTIONS;
  }
};

export const savePromotion = async (promo: Promotion): Promise<void> => {
  const promos = await getPromotions();
  const index = promos.findIndex(p => p.id === promo.id);
  
  let newPromos;
  if (index >= 0) {
    newPromos = [...promos];
    newPromos[index] = promo;
  } else {
    newPromos = [...promos, promo];
  }
  
  localStorage.setItem(PROMO_STORAGE_KEY, JSON.stringify(newPromos));
  window.dispatchEvent(new Event('promos-updated'));
};

export const deletePromotion = async (id: string): Promise<void> => {
  const promos = await getPromotions();
  const newPromos = promos.filter(p => p.id !== id);
  localStorage.setItem(PROMO_STORAGE_KEY, JSON.stringify(newPromos));
  window.dispatchEvent(new Event('promos-updated'));
};

// --- Order Services ---

export const getOrders = async (): Promise<Order[]> => {
  try {
    const stored = localStorage.getItem(ORDER_STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error("Error loading orders", error);
    return [];
  }
};

export const placeOrder = async (order: Order): Promise<void> => {
  // 1. Calculate Required Ingredients
  let allIngredients: { inventoryItemId: string, quantity: number }[] = [];
  
  order.items.forEach(item => {
      const required = getRequiredIngredients(item.id, item.quantity);
      // Aggregate quantities
      required.forEach(req => {
          const existing = allIngredients.find(x => x.inventoryItemId === req.inventoryItemId);
          if (existing) {
              existing.quantity += req.quantity;
          } else {
              allIngredients.push({ ...req });
          }
      });
  });

  // 2. Attempt to Deduct Inventory (will throw if OOS)
  try {
      if (allIngredients.length > 0) {
          await deductInventory(allIngredients);
      }
  } catch (e: any) {
      console.error("Inventory Error", e);
      throw new Error(e.message || "Inventory issue preventing order");
  }

  // 3. Place Order
  const orders = await getOrders();
  const newOrders = [...orders, order];
  localStorage.setItem(ORDER_STORAGE_KEY, JSON.stringify(newOrders));
  window.dispatchEvent(new Event('order-updated'));
};

export const updateOrderStatus = async (
  orderId: string, 
  status: OrderStatus, 
  cancellationReason?: string
): Promise<void> => {
  const orders = await getOrders();
  const newOrders = orders.map(order => {
    if (order.id === orderId) {
      return {
        ...order,
        status,
        cancellationReason: cancellationReason || order.cancellationReason
      };
    }
    return order;
  });
  
  localStorage.setItem(ORDER_STORAGE_KEY, JSON.stringify(newOrders));
  window.dispatchEvent(new Event('order-updated'));
};

export const getLastCustomerOrder = async (phoneNumber: string): Promise<Order | null> => {
  try {
    const orders = await getOrders();
    const userOrders = orders.filter(o => o.loyaltyUserPhone === phoneNumber);
    if (userOrders.length === 0) return null;
    
    // Sort descending by timestamp
    return userOrders.sort((a, b) => b.timestamp - a.timestamp)[0];
  } catch (e) {
    console.error("Error getting last order", e);
    return null;
  }
};

// --- Loyalty Services ---

const getLoyaltyUsers = (): Record<string, LoyaltyUser> => {
    try {
        const stored = localStorage.getItem(LOYALTY_STORAGE_KEY);
        return stored ? JSON.parse(stored) : {};
    } catch {
        return {};
    }
};

const saveLoyaltyUsers = (users: Record<string, LoyaltyUser>) => {
    localStorage.setItem(LOYALTY_STORAGE_KEY, JSON.stringify(users));
};

export const getLoyaltyAccount = async (phoneNumber: string, name?: string, email?: string): Promise<LoyaltyUser> => {
    const users = getLoyaltyUsers();
    
    if (users[phoneNumber]) {
        // Update existing user with new details if provided (e.g. converting a guest or updating profile)
        if (name || email) {
            users[phoneNumber] = {
                ...users[phoneNumber],
                name: name || users[phoneNumber].name,
                email: email || users[phoneNumber].email
            };
            saveLoyaltyUsers(users);
        }
        return users[phoneNumber];
    }
    
    // Create new if doesn't exist
    const newUser: LoyaltyUser = {
        phoneNumber,
        name,
        email,
        points: 0,
        history: [],
        savedFavorites: []
    };
    users[phoneNumber] = newUser;
    saveLoyaltyUsers(users);
    return newUser;
};

export const addLoyaltyPoints = async (phoneNumber: string, points: number, description: string): Promise<LoyaltyUser> => {
    const users = getLoyaltyUsers();
    const user = users[phoneNumber] || { phoneNumber, points: 0, history: [], savedFavorites: [] };
    
    user.points += points;
    user.history.unshift({
        id: Math.random().toString(36).substr(2, 9),
        date: Date.now(),
        activity: description,
        pointsChange: points
    });
    
    users[phoneNumber] = user;
    saveLoyaltyUsers(users);
    return user;
};

export const redeemLoyaltyPoints = async (phoneNumber: string, pointsCost: number, rewardName: string): Promise<LoyaltyUser | null> => {
    const users = getLoyaltyUsers();
    const user = users[phoneNumber];
    
    if (!user || user.points < pointsCost) return null;

    user.points -= pointsCost;
    user.history.unshift({
        id: Math.random().toString(36).substr(2, 9),
        date: Date.now(),
        activity: `Redeemed: ${rewardName}`,
        pointsChange: -pointsCost
    });

    users[phoneNumber] = user;
    saveLoyaltyUsers(users);
    return user;
};

export const saveUserFavorite = async (phoneNumber: string, favorite: SavedFavorite): Promise<LoyaltyUser | null> => {
    const users = getLoyaltyUsers();
    const user = users[phoneNumber];
    if (!user) return null;

    if (!user.savedFavorites) user.savedFavorites = [];
    user.savedFavorites.push(favorite);
    
    users[phoneNumber] = user;
    saveLoyaltyUsers(users);
    return user;
};
