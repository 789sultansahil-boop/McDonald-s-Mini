
import { InventoryItem, MenuItem } from '../types';
import { INITIAL_INVENTORY, RECIPES } from '../constants';

const INVENTORY_KEY = 'mcd_inventory_butranwali';

// -- Core Inventory Logic --

export const getInventory = async (): Promise<InventoryItem[]> => {
    try {
        const stored = localStorage.getItem(INVENTORY_KEY);
        if (stored) {
            return JSON.parse(stored);
        }
        // Initialize
        localStorage.setItem(INVENTORY_KEY, JSON.stringify(INITIAL_INVENTORY));
        return INITIAL_INVENTORY;
    } catch {
        return INITIAL_INVENTORY;
    }
};

export const saveInventory = async (items: InventoryItem[]) => {
    localStorage.setItem(INVENTORY_KEY, JSON.stringify(items));
    window.dispatchEvent(new Event('inventory-updated'));
};

export const restockItem = async (itemId: string, amount: number) => {
    const items = await getInventory();
    const updated = items.map(i => i.id === itemId ? { ...i, quantity: i.quantity + amount } : i);
    await saveInventory(updated);
};

export const deductInventory = async (itemsToDeduct: { inventoryItemId: string, quantity: number }[]) => {
    const items = await getInventory();
    
    // Validate first (Atomic transaction simulation)
    for (const d of itemsToDeduct) {
        const item = items.find(i => i.id === d.inventoryItemId);
        if (!item || item.quantity < d.quantity) {
            throw new Error(`Out of stock: ${item?.name || 'Unknown Item'}`);
        }
    }

    // Deduct
    const updated = items.map(i => {
        const deduction = itemsToDeduct.find(d => d.inventoryItemId === i.id);
        return deduction ? { ...i, quantity: i.quantity - deduction.quantity } : i;
    });

    await saveInventory(updated);
};

// -- Recipe / Menu Availability Logic --

export const checkMenuAvailability = (menuItem: MenuItem, inventory: InventoryItem[]): boolean => {
    // If not enabled by admin, it's unavailable regardless of stock
    if (!menuItem.available) return false;

    const recipe = RECIPES.find(r => r.menuItemId === menuItem.id);
    if (!recipe) return true; // No recipe means no tracked ingredients (assumed available)

    return recipe.ingredients.every(ing => {
        const stockItem = inventory.find(i => i.id === ing.inventoryItemId);
        return stockItem && stockItem.quantity >= ing.quantity;
    });
};

export const getRequiredIngredients = (menuItemId: string, quantity: number): { inventoryItemId: string, quantity: number }[] => {
    const recipe = RECIPES.find(r => r.menuItemId === menuItemId);
    if (!recipe) return [];
    return recipe.ingredients.map(ing => ({
        inventoryItemId: ing.inventoryItemId,
        quantity: ing.quantity * quantity
    }));
};
