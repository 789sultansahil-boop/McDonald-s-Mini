
import React, { useEffect, useState } from 'react';
import { Order, OrderStatus, InventoryItem } from '../types';
import { getOrders, updateOrderStatus } from '../services/storageService';
import { getInventory, restockItem } from '../services/inventoryService';
import { Clock, CheckCircle, ChefHat, Bell, DollarSign, History, Utensils, XCircle, Car, CalendarClock, AlertTriangle, Package, RefreshCw } from 'lucide-react';

const KitchenDashboard: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'active' | 'completed' | 'pantry'>('active');
  
  // Inventory State
  const [inventory, setInventory] = useState<InventoryItem[]>([]);

  const fetchOrders = async () => {
    const data = await getOrders();
    setOrders(data.sort((a, b) => b.timestamp - a.timestamp));
    setLoading(false);
  };
  
  const fetchInventory = async () => {
      const inv = await getInventory();
      setInventory(inv);
  };

  useEffect(() => {
    fetchOrders();
    fetchInventory();
    const interval = setInterval(() => { fetchOrders(); fetchInventory(); }, 5000);
    const handleStorageChange = () => fetchOrders();
    const handleInventoryChange = () => fetchInventory();
    
    window.addEventListener('order-updated', handleStorageChange);
    window.addEventListener('inventory-updated', handleInventoryChange);
    return () => {
      clearInterval(interval);
      window.removeEventListener('order-updated', handleStorageChange);
      window.removeEventListener('inventory-updated', handleInventoryChange);
    };
  }, []);

  const handleStatusUpdate = async (orderId: string, status: OrderStatus) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
    await updateOrderStatus(orderId, status);
  };
  
  const handleRestock = async (itemId: string) => {
      await restockItem(itemId, 20); // Add 20 units
      fetchInventory();
  };

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case OrderStatus.PENDING: return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case OrderStatus.PREPARING: return 'bg-blue-100 text-blue-800 border-blue-200';
      case OrderStatus.READY: return 'bg-purple-100 text-purple-800 border-purple-200';
      case OrderStatus.SERVED: return 'bg-green-100 text-green-800 border-green-200';
      case OrderStatus.PAID: return 'bg-gray-100 text-gray-800 border-gray-200';
      case OrderStatus.CANCELLED: return 'bg-red-100 text-red-800 border-red-200';
      case OrderStatus.FAILED: return 'bg-red-100 text-red-800 border-red-200';
      case OrderStatus.REFUNDED: return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const activeOrders = orders.filter(o => 
    [OrderStatus.PENDING, OrderStatus.PREPARING, OrderStatus.READY, OrderStatus.SERVED].includes(o.status)
  );
  
  const completedOrders = orders.filter(o => 
    [OrderStatus.PAID, OrderStatus.CANCELLED, OrderStatus.FAILED, OrderStatus.REFUNDED].includes(o.status)
  );

  // Separation Logic for Distinct Queues
  const driveThruOrders = activeOrders.filter(o => o.orderType === 'drive-thru');
  const standardOrders = activeOrders.filter(o => o.orderType !== 'drive-thru');

  // Drive Thru Stats
  const driveThruQueueLength = driveThruOrders.filter(o => o.status === OrderStatus.PENDING || o.status === OrderStatus.PREPARING).length;
  const isHighTraffic = driveThruQueueLength > 5;
  
  // Low Stock Logic
  const lowStockItems = inventory.filter(i => i.quantity <= i.threshold);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-gray-500">Loading Dashboard...</div>;
  }

  const OrderCard = ({ order }: { order: Order }) => (
    <div key={order.id} className={`bg-white rounded-xl shadow-sm border overflow-hidden flex flex-col ${order.orderType === 'drive-thru' && isHighTraffic ? 'border-red-500 ring-2 ring-red-100' : 'border-gray-200'} ${order.status === OrderStatus.CANCELLED || order.status === OrderStatus.FAILED ? 'opacity-75' : ''}`}>
        {/* Order Header */}
        <div className={`p-4 border-b flex justify-between items-start ${order.orderType === 'drive-thru' ? 'bg-red-50 border-red-100' : 'bg-gray-50/50 border-gray-100'}`}>
        <div>
            <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg text-gray-900">
                    {order.orderType === 'dine-in' ? `Table ${order.tableNumber}` : order.orderType === 'curbside' ? 'Curbside' : order.orderType === 'drive-thru' ? 'Drive-Thru' : 'Pickup'}
                </h3>
                {order.orderType === 'curbside' && <Car size={16} className="text-blue-600"/>}
                {order.orderType === 'drive-thru' && <Car size={16} className="text-red-600"/>}
                {order.orderType === 'pickup' && <Clock size={16} className="text-orange-600"/>}
            </div>
            <span className="text-xs text-gray-500 font-mono">#{order.id}</span>
        </div>
        <span className={`px-2 py-1 rounded-full text-xs font-bold border ${getStatusColor(order.status)}`}>
            {order.status === OrderStatus.READY && order.orderType === 'drive-thru' ? 'Window 1' : order.status}
        </span>
        </div>

        {/* Curbside / Schedule Details */}
        {(order.orderType === 'curbside' && order.curbsideDetails) && (
            <div className="px-4 py-2 bg-blue-50 text-blue-900 text-xs border-b border-blue-100">
                <p className="font-bold">{order.curbsideDetails.carModel} • {order.curbsideDetails.carColor}</p>
                <p className="font-mono">{order.curbsideDetails.licensePlate}</p>
                {order.curbsideDetails.isArrived && (
                    <div className="mt-1 flex items-center gap-1 font-bold text-red-600 animate-pulse">
                        <Bell size={12} /> CUSTOMER ARRIVED
                    </div>
                )}
            </div>
        )}
        {(order.orderType === 'pickup' && order.scheduledTime) && (
            <div className="px-4 py-2 bg-orange-50 text-orange-900 text-xs border-b border-orange-100 flex items-center gap-2">
                <CalendarClock size={14} />
                <span>Scheduled: {new Date(order.scheduledTime).toLocaleString()}</span>
            </div>
        )}

        {/* Order Items */}
        <div className="p-4 flex-1">
        <ul className="space-y-3">
            {order.items.map((item, idx) => (
            <li key={idx} className="flex flex-col text-sm">
                <div className="flex justify-between items-start">
                <div className="flex gap-2">
                    <span className="font-bold w-5 h-5 bg-gray-100 rounded flex items-center justify-center text-xs shrink-0">{item.quantity}x</span>
                    <span className="text-gray-700">{item.name}</span>
                </div>
                </div>
                {(item.selectedVariant || (item.selectedModifiers && item.selectedModifiers.length > 0)) && (
                <div className="pl-7 text-xs text-gray-500 mt-1">
                    {item.selectedVariant && <span className="block">{item.selectedVariant.name}</span>}
                    {item.selectedModifiers?.map((mod, i) => (
                        <span key={i} className="block">+ {mod.optionName}</span>
                    ))}
                </div>
                )}
                {item.itemNote && (
                <div className="pl-7 text-xs text-red-600 font-medium mt-1 italic">
                    "{item.itemNote}"
                </div>
                )}
            </li>
            ))}
        </ul>
        {/* Failure/Refund Reason Display */}
        {(order.status === OrderStatus.FAILED || order.status === OrderStatus.REFUNDED) && order.cancellationReason && (
            <div className="mt-3 p-2 bg-red-50 text-red-700 text-xs rounded border border-red-100">
                <span className="font-bold">Reason:</span> {order.cancellationReason}
            </div>
        )}
        </div>

        {/* Actions */}
        <div className="p-4 bg-gray-50 border-t border-gray-100 grid grid-cols-2 gap-2">
        {order.status === OrderStatus.PENDING && (
            <button 
            onClick={() => handleStatusUpdate(order.id, OrderStatus.PREPARING)}
            className="col-span-2 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition"
            >
            <ChefHat size={16}/> Start Cooking
            </button>
        )}
        {order.status === OrderStatus.PREPARING && (
            <button 
            onClick={() => handleStatusUpdate(order.id, order.orderType === 'dine-in' ? OrderStatus.SERVED : OrderStatus.READY)}
            className="col-span-2 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition"
            >
            <CheckCircle size={16}/> {order.orderType === 'dine-in' ? 'Mark Served' : order.orderType === 'drive-thru' ? 'Call to Window' : 'Mark Ready'}
            </button>
        )}
        {order.status === OrderStatus.READY && (
            <button 
            onClick={() => handleStatusUpdate(order.id, OrderStatus.SERVED)}
            className="col-span-2 bg-green-700 hover:bg-green-800 text-white py-2 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition"
            >
            <CheckCircle size={16}/> Complete Handoff
            </button>
        )}
            {order.status === OrderStatus.SERVED && (
            <button 
            onClick={() => handleStatusUpdate(order.id, OrderStatus.PAID)}
            className="col-span-2 bg-gray-900 hover:bg-black text-white py-2 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition"
            >
            <DollarSign size={16}/> Payment Received
            </button>
        )}
        {order.status === OrderStatus.PAID && (
                <div className="col-span-2 flex items-center justify-center gap-2 text-green-700 text-sm font-bold py-2 bg-green-50 rounded-lg">
                    <CheckCircle size={16} /> Completed
                </div>
        )}
        </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-6 flex flex-col md:flex-row gap-6">
      
      {/* Sidebar / Navigation */}
      <div className="w-full md:w-64 bg-white rounded-xl shadow-sm border border-gray-200 p-4 shrink-0 h-fit md:sticky md:top-6">
           <h1 className="font-serif text-2xl font-bold text-gray-900 mb-6">Kitchen View</h1>
           
           <nav className="space-y-2">
               <button 
                onClick={() => setActiveTab('active')}
                className={`w-full flex items-center justify-between p-3 rounded-lg font-bold transition ${activeTab === 'active' ? 'bg-primary text-white shadow-lg' : 'text-gray-600 hover:bg-gray-50'}`}
               >
                   <div className="flex items-center gap-2"><Utensils size={18}/> Active Orders</div>
                   <span className="bg-white/20 px-2 py-0.5 rounded text-xs">{activeOrders.length}</span>
               </button>
               
               {/* Drive Thru Stat Sub-item */}
               {driveThruQueueLength > 0 && (
                   <div className="pl-8 pr-3 py-1 flex justify-between items-center text-xs text-gray-500 font-medium">
                       <span className="flex items-center gap-1"><Car size={12}/> Drive-Thru Queue</span>
                       <span className={`${isHighTraffic ? 'text-red-600 font-bold animate-pulse' : ''}`}>{driveThruQueueLength}</span>
                   </div>
               )}

               <button 
                onClick={() => setActiveTab('completed')}
                className={`w-full flex items-center justify-between p-3 rounded-lg font-bold transition ${activeTab === 'completed' ? 'bg-secondary text-white shadow-lg' : 'text-gray-600 hover:bg-gray-50'}`}
               >
                   <div className="flex items-center gap-2"><History size={18}/> History</div>
               </button>
               <button 
                onClick={() => setActiveTab('pantry')}
                className={`w-full flex items-center justify-between p-3 rounded-lg font-bold transition ${activeTab === 'pantry' ? 'bg-orange-500 text-white shadow-lg' : 'text-gray-600 hover:bg-gray-50'}`}
               >
                   <div className="flex items-center gap-2"><Package size={18}/> Pantry</div>
                   {lowStockItems.length > 0 && <span className="bg-red-600 text-white w-5 h-5 flex items-center justify-center rounded-full text-xs animate-pulse">!</span>}
               </button>
           </nav>

           {/* Quick Alerts Sidebar */}
           {lowStockItems.length > 0 && activeTab !== 'pantry' && (
               <div className="mt-8">
                   <h4 className="text-xs font-bold uppercase text-gray-400 mb-2 tracking-widest">Stock Alerts</h4>
                   <div className="space-y-2">
                       {lowStockItems.map(item => (
                           <div key={item.id} className="bg-red-50 text-red-700 text-xs p-2 rounded border border-red-100 flex justify-between items-center">
                               <span>{item.name}</span>
                               <span className="font-bold">{item.quantity} {item.unit}</span>
                           </div>
                       ))}
                   </div>
               </div>
           )}
      </div>

      {/* Main Content Area */}
      <div className="flex-1">
        {/* Priority Alert Banner */}
        {isHighTraffic && activeTab === 'active' && (
            <div className="bg-red-600 text-white p-4 rounded-xl shadow-lg mb-6 flex items-center justify-between animate-pulse">
                <div className="flex items-center gap-3">
                    <AlertTriangle size={32} />
                    <div>
                        <h3 className="text-xl font-bold">HIGH TRAFFIC ALERT</h3>
                        <p className="font-medium opacity-90">Drive-Thru Queue is backing up ({driveThruQueueLength} cars). Prioritize Drive-Thru orders.</p>
                    </div>
                </div>
                <div className="bg-white text-red-600 font-bold px-4 py-2 rounded-lg">
                    PRIORITY MODE
                </div>
            </div>
        )}

        {activeTab === 'pantry' ? (
             <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                 <div className="p-6 border-b border-gray-200 flex justify-between items-center">
                     <div>
                        <h2 className="text-xl font-bold text-gray-900">Inventory Management</h2>
                        <p className="text-gray-500 text-sm">Real-time stock tracking</p>
                     </div>
                     <button onClick={fetchInventory} className="text-gray-400 hover:text-primary"><RefreshCw size={20}/></button>
                 </div>
                 <div className="overflow-x-auto">
                     <table className="w-full text-left text-sm">
                         <thead className="bg-gray-50 text-gray-500 uppercase tracking-wider font-bold">
                             <tr>
                                 <th className="p-4">Item Name</th>
                                 <th className="p-4">Current Stock</th>
                                 <th className="p-4">Status</th>
                                 <th className="p-4 text-right">Action</th>
                             </tr>
                         </thead>
                         <tbody className="divide-y divide-gray-100">
                             {inventory.map(item => {
                                 const isLow = item.quantity <= item.threshold;
                                 const isEmpty = item.quantity === 0;
                                 return (
                                     <tr key={item.id} className={isLow ? 'bg-red-50/50' : ''}>
                                         <td className="p-4 font-bold text-gray-900">{item.name}</td>
                                         <td className="p-4 font-mono">
                                             <span className={`text-lg ${isLow ? 'text-red-600 font-bold' : 'text-gray-700'}`}>
                                                 {item.quantity}
                                             </span>
                                             <span className="text-gray-400 text-xs ml-1">{item.unit}</span>
                                         </td>
                                         <td className="p-4">
                                             {isEmpty ? (
                                                 <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-red-100 text-red-700 font-bold text-xs">
                                                     <XCircle size={12}/> OUT OF STOCK
                                                 </span>
                                             ) : isLow ? (
                                                 <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-orange-100 text-orange-700 font-bold text-xs">
                                                     <AlertTriangle size={12}/> LOW STOCK
                                                 </span>
                                             ) : (
                                                 <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full bg-green-100 text-green-700 font-bold text-xs">
                                                     <CheckCircle size={12}/> OK
                                                 </span>
                                             )}
                                         </td>
                                         <td className="p-4 text-right">
                                             <button 
                                                onClick={() => handleRestock(item.id)}
                                                className="bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 px-3 py-1.5 rounded-lg text-xs font-bold shadow-sm transition active:scale-95"
                                             >
                                                 + Refill (20)
                                             </button>
                                         </td>
                                     </tr>
                                 );
                             })}
                         </tbody>
                     </table>
                 </div>
             </div>
        ) : (
            // Orders View
            <div className="space-y-8">
                
                {/* Drive Thru Priority Section */}
                {activeTab === 'active' && driveThruOrders.length > 0 && (
                    <div className="animate-in slide-in-from-left duration-500">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-red-700 font-black text-xl flex items-center gap-2">
                                <span className="bg-red-100 p-2 rounded-lg"><Car size={24}/></span>
                                Drive-Thru Lane
                                <span className="bg-red-600 text-white text-xs px-2 py-1 rounded-full">{driveThruOrders.length}</span>
                            </h2>
                            {isHighTraffic && <span className="text-xs font-bold text-red-600 bg-red-50 px-2 py-1 rounded border border-red-100">PRIORITY QUEUE</span>}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-4 bg-red-50/50 rounded-2xl border border-red-100 border-dashed">
                            {driveThruOrders.map(order => (
                                <OrderCard key={order.id} order={order} />
                            ))}
                        </div>
                    </div>
                )}

                {/* Standard Queue Section */}
                {activeTab === 'active' && (
                    <div>
                        {driveThruOrders.length > 0 && (
                            <div className="flex items-center gap-2 mb-4 mt-8 opacity-60">
                                <h2 className="text-gray-900 font-bold text-lg flex items-center gap-2">
                                    <Utensils size={20}/> Standard Queue
                                </h2>
                                <div className="h-px bg-gray-300 flex-1"></div>
                            </div>
                        )}
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {(driveThruOrders.length > 0 ? standardOrders : activeOrders).map(order => (
                                <OrderCard key={order.id} order={order} />
                            ))}
                            {activeTab === 'active' && activeOrders.length === 0 && (
                                <div className="col-span-full py-20 text-center text-gray-400">
                                    <Clock size={48} className="mx-auto mb-4 opacity-20"/>
                                    <p className="font-medium">No active orders</p>
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* Completed Orders Tab */}
                {activeTab === 'completed' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                         {completedOrders.map(order => (
                             <OrderCard key={order.id} order={order} />
                         ))}
                    </div>
                )}
            </div>
        )}

      </div>
    </div>
  );
};

export default KitchenDashboard;
