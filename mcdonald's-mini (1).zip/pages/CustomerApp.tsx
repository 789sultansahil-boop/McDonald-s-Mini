
import React, { useState, useMemo, useEffect } from 'react';
import { Category, MenuItem, CartItem, Order, OrderStatus, Variant, SelectedModifier, Promotion, LoyaltyUser, Reward, SavedFavorite, OrderType, InventoryItem } from '../types';
import MenuCard from '../components/MenuCard';
import VirtualWaiter from '../components/VirtualWaiter';
import ProductCustomizer from '../components/ProductCustomizer';
import HeroBanner from '../components/HeroBanner';
import LoyaltyModal from '../components/LoyaltyModal';
import { ShoppingBag, ChevronLeft, Minus, Plus, Utensils, Receipt, Settings2, Tag, MessageSquare, Gift, Award, Zap, ArrowRight, Leaf, WheatOff, Star, Sparkles, Car, Clock, User, CheckCircle, MapPin, AlertCircle, LogIn, UserPlus, Heart, X, Trash2, Gauge } from 'lucide-react';
import { placeOrder, getMenuItems, getOrders, getPromotions, addLoyaltyPoints, redeemLoyaltyPoints, getLoyaltyAccount, updateOrderStatus } from '../services/storageService';
import { getInventory, checkMenuAvailability } from '../services/inventoryService';
import { POINTS_PER_DOLLAR } from '../constants';

// Internal Component for Upsell
const CartUpsell: React.FC<{ cart: CartItem[], menuItems: MenuItem[], onAdd: (item: MenuItem, discount?: {name: string, amount: number}) => void }> = ({ cart, menuItems, onAdd }) => {
    const mainItems = cart.filter(i => i.category === Category.BURGER || i.category === Category.CHICKEN || i.category === Category.SANDWICH || i.category === Category.PIZZA);
    const sideItems = cart.filter(i => i.category === Category.SIDES);
    const drinkItems = cart.filter(i => i.category === Category.DRINK);

    const mainsCount = mainItems.reduce((acc, i) => acc + i.quantity, 0);
    const sidesCount = sideItems.reduce((acc, i) => acc + i.quantity, 0);
    const drinksCount = drinkItems.reduce((acc, i) => acc + i.quantity, 0);

    // Logic: If user has mains but missing sides or drinks
    if (mainsCount > 0 && (sidesCount < mainsCount || drinksCount < mainsCount)) {
        let offerItem: MenuItem | undefined;
        let offerText = '';
        let discountPercent = 0.20; // 20% off upsell

        const fries = menuItems.find(i => i.name.includes('Fries'));
        const coke = menuItems.find(i => i.name.includes('Coca-Cola'));

        if (sidesCount < mainsCount && drinksCount < mainsCount && fries && coke) {
            // Missing Both - Offer Fries (Simple logic: offer one, maybe chain later)
            offerItem = fries;
            offerText = "Make it a meal? Add Fries!";
        } else if (sidesCount < mainsCount && fries) {
            offerItem = fries;
            offerText = "Forget the Fries?";
        } else if (drinksCount < mainsCount && coke) {
            offerItem = coke;
            offerText = "Thirsty? Add a Coke.";
        }

        if (offerItem && offerItem.available) {
            const discountAmount = offerItem.price * discountPercent;
            return (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mt-4 flex items-center justify-between animate-in slide-in-from-right">
                    <div>
                        <p className="text-sm font-bold text-yellow-900">{offerText}</p>
                        <p className="text-xs text-yellow-700">Get 20% off this item</p>
                    </div>
                    <button 
                        onClick={() => onAdd(offerItem!, { name: "Combo Deal", amount: discountAmount })}
                        className="bg-primary text-white text-xs px-3 py-2 rounded-full font-bold shadow-sm hover:bg-red-700"
                    >
                        Add for ${(offerItem.price - discountAmount).toFixed(2)}
                    </button>
                </div>
            );
        }
    }
    return null;
};

const CustomerApp: React.FC = () => {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  
  // Checkout State
  const [orderType, setOrderType] = useState<OrderType>('dine-in');
  const [tableNumber, setTableNumber] = useState('');
  const [customerNote, setCustomerNote] = useState('');
  const [curbsideDetails, setCurbsideDetails] = useState({ carModel: '', carColor: '', licensePlate: '' });
  const [scheduledTime, setScheduledTime] = useState('');
  const [guestContact, setGuestContact] = useState({ name: '', email: '', phone: '' });

  const [orderPlaced, setOrderPlaced] = useState(false);
  const [lastOrder, setLastOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  // Queue tracking for Drive-Thru
  const [queuePosition, setQueuePosition] = useState<number | null>(null);

  // Filters State
  const [activeFilters, setActiveFilters] = useState<Set<string>>(new Set());

  // Loyalty State
  const [isLoyaltyOpen, setIsLoyaltyOpen] = useState(false);
  const [loyaltyAuthMode, setLoyaltyAuthMode] = useState<'signin' | 'signup'>('signin');
  const [loyaltyUser, setLoyaltyUser] = useState<LoyaltyUser | null>(null);
  const [activeReward, setActiveReward] = useState<Reward | null>(null);

  // Auth View State
  const [isWelcomeView, setIsWelcomeView] = useState(() => !localStorage.getItem('mcd_loyalty_phone'));

  // Customization State
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);

  // Personalized Offer State
  const [personalizedOffer, setPersonalizedOffer] = useState<{title: string, discount: number, category: string} | null>(null);

  const categories = ['All', ...Object.values(Category)];

  useEffect(() => {
    const loadData = async () => {
      try {
        const [items, promos, inv] = await Promise.all([getMenuItems(), getPromotions(), getInventory()]);
        setMenuItems(items);
        setPromotions(promos);
        setInventory(inv);
      } catch (e) {
        console.error("Failed to load data", e);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();

    // Check for cached loyalty user
    const cachedPhone = localStorage.getItem('mcd_loyalty_phone');
    if (cachedPhone) {
        getLoyaltyAccount(cachedPhone).then(user => {
            setLoyaltyUser(user);
            generatePersonalizedOffer(user);
            setGuestContact(prev => ({...prev, phone: user.phoneNumber, name: user.name, email: user.email}));
            setIsWelcomeView(false);
        });
    }

    const handleMenuUpdate = () => loadData();
    const handleOrderUpdate = () => {
        if (lastOrder) {
            getOrders().then(orders => {
                const updated = orders.find(o => o.id === lastOrder.id);
                if (updated) {
                    setLastOrder(updated);
                }
                
                // Update queue position for Drive-Thru
                if (updated && updated.orderType === 'drive-thru' && (updated.status === OrderStatus.PENDING || updated.status === OrderStatus.PREPARING)) {
                    const driveThruOrders = orders.filter(o => 
                        o.orderType === 'drive-thru' && 
                        (o.status === OrderStatus.PENDING || o.status === OrderStatus.PREPARING) &&
                        o.timestamp < updated.timestamp
                    );
                    setQueuePosition(driveThruOrders.length);
                } else {
                    setQueuePosition(null);
                }
            });
        }
    };
    const handleInventoryUpdate = async () => {
        const inv = await getInventory();
        setInventory(inv);
    };

    window.addEventListener('menu-updated', handleMenuUpdate);
    window.addEventListener('promos-updated', handleMenuUpdate);
    window.addEventListener('order-updated', handleOrderUpdate);
    window.addEventListener('inventory-updated', handleInventoryUpdate);
    
    // Poll for queue updates if active order
    const queueInterval = setInterval(handleOrderUpdate, 5000);

    return () => {
        window.removeEventListener('menu-updated', handleMenuUpdate);
        window.removeEventListener('promos-updated', handleMenuUpdate);
        window.removeEventListener('order-updated', handleOrderUpdate);
        window.removeEventListener('inventory-updated', handleInventoryUpdate);
        clearInterval(queueInterval);
    };
  }, [lastOrder]);

  const generatePersonalizedOffer = (user: LoyaltyUser) => {
      const hasOrderHistory = user.history.length > 2;
      if (hasOrderHistory) {
          setPersonalizedOffer({
              title: "Welcome Back Deal",
              discount: 0.10,
              category: 'All'
          });
      }
  };

  const filteredItems = useMemo(() => {
    let items = selectedCategory === 'All'
      ? menuItems
      : menuItems.filter(item => item.category === selectedCategory);
    
    if (activeFilters.has('Vegetarian')) items = items.filter(i => i.dietaryInfo?.isVegetarian);
    if (activeFilters.has('Vegan')) items = items.filter(i => i.dietaryInfo?.isVegan);
    if (activeFilters.has('Gluten Free')) items = items.filter(i => i.dietaryInfo?.isGlutenFree);

    return items;
  }, [selectedCategory, menuItems, activeFilters]);

  const toggleFilter = (filter: string) => {
      const newFilters = new Set(activeFilters);
      if (newFilters.has(filter)) newFilters.delete(filter);
      else newFilters.add(filter);
      setActiveFilters(newFilters);
  };

  const addToCart = (
      item: MenuItem, 
      quantity = 1, 
      selectedVariant?: Variant, 
      selectedModifiers?: SelectedModifier[],
      itemNote?: string,
      specialDiscount?: { name: string, amount: number }
  ) => {
    let basePrice = item.price;
    if (selectedVariant) basePrice = selectedVariant.price;
    if (selectedModifiers) selectedModifiers.forEach(mod => basePrice += mod.price);

    let finalPrice = basePrice;
    let appliedDiscount = specialDiscount;

    if (!appliedDiscount) {
        if (personalizedOffer) {
             const discountAmount = basePrice * personalizedOffer.discount;
             finalPrice = basePrice - discountAmount;
             appliedDiscount = { name: personalizedOffer.title, amount: discountAmount };
        } else {
            const activePromo = promotions.find(p => 
                p.isActive && p.endDate > Date.now() && 
                (p.targetCategory === 'All' || p.targetCategory === item.category)
            );
            if (activePromo) {
                const discountAmount = basePrice * (activePromo.discountPercent / 100);
                finalPrice = basePrice - discountAmount;
                appliedDiscount = { name: activePromo.title, amount: discountAmount };
            }
        }
    } else {
        finalPrice = basePrice - specialDiscount.amount;
    }

    const newItem: CartItem = {
        ...item,
        cartId: Math.random().toString(36).substr(2, 9),
        quantity,
        selectedVariant,
        selectedModifiers,
        itemNote,
        finalPrice,
        appliedDiscount
    };
    setCart(prev => [...prev, newItem]);
    setIsCartOpen(true);
  };

  const addFavoriteToCart = (fav: SavedFavorite) => {
      const baseItem = menuItems.find(i => i.id === fav.baseItemId);
      if (!baseItem) return;
      addToCart(baseItem, 1, fav.selectedVariant, fav.selectedModifiers, fav.itemNote);
  };

  const removeFromCart = (cartId: string) => {
    setCart(prev => prev.filter(i => i.cartId !== cartId));
  };

  const handleLogin = (user: LoyaltyUser) => {
    setLoyaltyUser(user);
    generatePersonalizedOffer(user);
    localStorage.setItem('mcd_loyalty_phone', user.phoneNumber);
    setGuestContact(prev => ({...prev, phone: user.phoneNumber, name: user.name, email: user.email}));
    setIsWelcomeView(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('mcd_loyalty_phone');
    setLoyaltyUser(null);
    setPersonalizedOffer(null);
    setGuestContact({ name: '', email: '', phone: '' });
    setIsLoyaltyOpen(false);
    setIsWelcomeView(true);
  };

  const openSignIn = () => {
    setLoyaltyAuthMode('signin');
    setIsLoyaltyOpen(true);
  };

  const openSignUp = () => {
    setLoyaltyAuthMode('signup');
    setIsLoyaltyOpen(true);
  };

  const handleRedeemReward = (reward: Reward) => {
    setActiveReward(reward);
    setIsLoyaltyOpen(false);
    setIsCartOpen(true);
  };

  const handleRemoveReward = () => {
    setActiveReward(null);
  };

  const handleReorder = (order: Order) => {
    const newCartItems = order.items.map(item => ({
        ...item,
        cartId: Math.random().toString(36).substr(2, 9)
    }));
    setCart(newCartItems);
    setIsLoyaltyOpen(false);
    setIsCartOpen(true);
  };

  const handleArrived = async () => {
    if (!lastOrder) return;
    await updateOrderStatus(lastOrder.id, lastOrder.status); // Trigger logic update
    alert("Kitchen notified! Someone will be out shortly.");
  };

  let subtotal = cart.reduce((sum, item) => sum + (item.finalPrice * item.quantity), 0);
  let total = subtotal;
  if (activeReward && activeReward.discountAmount) {
      total = Math.max(0, subtotal - activeReward.discountAmount);
  }
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const potentialPoints = Math.floor(total * POINTS_PER_DOLLAR);

  const handleCheckout = async () => {
    if (orderType === 'dine-in' && !tableNumber) {
        alert("Please enter a table number");
        return;
    }
    if (orderType === 'curbside' && (!curbsideDetails.carModel || !curbsideDetails.licensePlate)) {
        alert("Please enter your car details for curbside pickup");
        return;
    }

    const newOrder: Order = {
      id: Math.random().toString(36).substring(7),
      tableNumber: orderType === 'dine-in' ? tableNumber : undefined,
      items: cart,
      total: total,
      status: OrderStatus.PENDING,
      timestamp: Date.now(),
      customerNote: customerNote.trim(),
      loyaltyPointsEarned: potentialPoints,
      loyaltyUserPhone: loyaltyUser?.phoneNumber,
      orderType,
      curbsideDetails: orderType === 'curbside' ? curbsideDetails : undefined,
      scheduledTime: scheduledTime ? new Date(scheduledTime).getTime() : undefined,
      guestContact: guestContact
    };

    try {
        await placeOrder(newOrder);

        if (loyaltyUser) {
            await addLoyaltyPoints(loyaltyUser.phoneNumber, potentialPoints, `Order #${newOrder.id}`);
            if (activeReward) {
                await redeemLoyaltyPoints(loyaltyUser.phoneNumber, activeReward.pointCost, activeReward.name);
                const freshUser = await getLoyaltyAccount(loyaltyUser.phoneNumber);
                setLoyaltyUser(freshUser);
            }
        }

        setLastOrder(newOrder);
        setOrderPlaced(true);
        setCart([]);
        setCustomerNote('');
        setActiveReward(null);
        setIsCartOpen(false);
    } catch (error: any) {
        alert(`Order Failed: ${error.message}`);
    }
  };

  // --- Render Functions ---

  const renderOrderTracker = () => {
      if (!lastOrder) return null;

      const isFailed = lastOrder.status === OrderStatus.FAILED;
      const isRefunded = lastOrder.status === OrderStatus.REFUNDED;
      const isCancelled = lastOrder.status === OrderStatus.CANCELLED;

      if (isFailed || isRefunded || isCancelled) {
          return (
              <div className="w-full mb-8 bg-red-50 border border-red-200 p-6 rounded-xl text-center">
                  <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <AlertCircle size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-red-900 mb-2">
                      {isRefunded ? 'Order Refunded' : isFailed ? 'Order Failed' : 'Order Cancelled'}
                  </h3>
                  <p className="text-red-700">
                      {lastOrder.cancellationReason || "There was an issue with your order."}
                  </p>
                  <p className="text-sm text-red-600 mt-2">Please ask the crew for assistance.</p>
              </div>
          );
      }

      // Special Drive-Thru Lane Visualization
      if (lastOrder.orderType === 'drive-thru' && (lastOrder.status === OrderStatus.PENDING || lastOrder.status === OrderStatus.PREPARING || lastOrder.status === OrderStatus.READY)) {
          return (
              <div className="w-full mb-8">
                  <div className="bg-gray-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden">
                      <div className="absolute top-0 right-0 p-12 opacity-10">
                          <Car size={150} />
                      </div>
                      
                      {lastOrder.status === OrderStatus.READY ? (
                          <div className="text-center py-6 animate-in zoom-in duration-500">
                              <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg animate-bounce">
                                  <CheckCircle size={40} className="text-white" />
                              </div>
                              <h3 className="text-3xl font-black text-green-400 mb-2">YOU'RE UP!</h3>
                              <p className="text-xl font-bold">Proceed to Window 1</p>
                              <p className="text-white/60 mt-2">Have your order number ready.</p>
                          </div>
                      ) : (
                          <div className="text-center py-4">
                              <h3 className="text-lg font-medium text-white/70 mb-6">Drive-Thru Lane Status</h3>
                              
                              <div className="flex justify-center items-end gap-2 mb-8 h-20">
                                  {/* Visualizing Cars */}
                                  {[2, 1, 0].map((offset) => {
                                      const isMe = offset === 0;
                                      return (
                                          <div key={offset} className={`relative flex flex-col items-center transition-all duration-500 ${isMe ? 'opacity-100 scale-110' : 'opacity-40 scale-90'}`}>
                                              {isMe && <div className="mb-2 bg-accent text-primary text-[10px] font-bold px-2 py-0.5 rounded-full">YOU</div>}
                                              <Car size={isMe ? 48 : 40} className={isMe ? 'text-accent' : 'text-gray-500'} />
                                              <div className="w-16 h-1 bg-gray-700 mt-1 rounded-full"></div>
                                          </div>
                                      );
                                  })}
                              </div>

                              <div className="bg-white/10 rounded-xl p-4 backdrop-blur-sm border border-white/10">
                                  <div className="text-4xl font-black text-accent mb-1">{queuePosition !== null ? queuePosition : '-'}</div>
                                  <div className="text-sm font-bold uppercase tracking-widest text-white/80">Cars Ahead</div>
                              </div>
                              <p className="text-xs text-white/50 mt-4">We're preparing your order fresh.</p>
                          </div>
                      )}
                  </div>
              </div>
          );
      }

      // Standard Tracker for Dine-In / Pickup / Curbside
      const steps = [
          { status: OrderStatus.PENDING, label: 'Pending' },
          { status: OrderStatus.PREPARING, label: 'Preparing' },
          { status: OrderStatus.READY, label: 'Ready' },
          { status: OrderStatus.SERVED, label: lastOrder.orderType === 'dine-in' ? 'Served' : 'Picked Up' }
      ];

      const currentStepIndex = steps.findIndex(s => s.status === lastOrder.status);
      let progressIndex = currentStepIndex;
      if (lastOrder.status === OrderStatus.PAID) progressIndex = 3;
      
      if (progressIndex === -1 && lastOrder.status !== OrderStatus.CANCELLED) {
         if (lastOrder.status === OrderStatus.SERVED) progressIndex = 3;
      }

      return (
          <div className="w-full mb-8">
              <div className="relative flex justify-between items-center mb-2">
                   <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-200 -z-10 rounded-full"></div>
                   <div 
                      className="absolute top-1/2 left-0 h-1 bg-green-500 -z-10 rounded-full transition-all duration-1000"
                      style={{ width: `${(progressIndex / 3) * 100}%` }}
                   ></div>

                   {steps.map((step, idx) => {
                       const isActive = idx <= progressIndex;
                       return (
                           <div key={idx} className="flex flex-col items-center">
                               <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all ${
                                   isActive 
                                    ? 'bg-green-500 border-green-500 text-white shadow-md scale-110' 
                                    : 'bg-white border-gray-300 text-gray-400'
                               }`}>
                                   {isActive ? <CheckCircle size={16} /> : idx + 1}
                               </div>
                               <span className={`text-[10px] font-bold mt-1 uppercase tracking-wider ${isActive ? 'text-green-600' : 'text-gray-400'}`}>
                                   {step.label}
                               </span>
                           </div>
                       )
                   })}
              </div>
              
              {lastOrder.status === OrderStatus.READY && lastOrder.orderType === 'curbside' && (
                  <div className="bg-blue-50 p-4 rounded-xl border border-blue-200 mt-6 text-center animate-in zoom-in">
                      <h4 className="font-bold text-blue-900 mb-2">Order Ready!</h4>
                      <p className="text-sm text-blue-700 mb-4">Park in the designated Curbside spot.</p>
                      <button 
                        onClick={handleArrived}
                        className="bg-blue-600 text-white px-6 py-3 rounded-full font-bold shadow-lg hover:bg-blue-700 active:scale-95 transition w-full"
                      >
                         <Car className="inline mr-2" /> I've Arrived
                      </button>
                  </div>
              )}
          </div>
      )
  };

  if (orderPlaced && lastOrder) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 text-center">
        <div className="w-full absolute top-0 bg-black text-white text-[10px] md:text-xs py-1 text-center font-medium">
             Website Owner: Asad Ali
        </div>
        
        <div className="w-full max-w-md mt-12">
            <h1 className="font-bold text-3xl text-gray-900 mb-2">Order Tracking</h1>
            <p className="text-gray-600 mb-8">Order #{lastOrder.id}</p>
            
            {renderOrderTracker()}

            <div className="bg-white w-full rounded-xl shadow-sm border border-gray-200 p-5 mb-8 text-left relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-primary"></div>
                <div className="flex justify-between items-center border-b border-gray-100 pb-3 mb-3">
                    <div className="flex items-center gap-2">
                        <Receipt size={16} className="text-gray-400"/>
                        <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Receipt</span>
                    </div>
                    <span className="text-xs font-bold bg-gray-100 px-2 py-1 rounded text-gray-600">
                        {lastOrder.orderType === 'curbside' ? 'Curbside' : lastOrder.orderType === 'drive-thru' ? 'Drive-Thru' : lastOrder.orderType === 'dine-in' ? 'Dine-In' : 'Pickup'}
                    </span>
                </div>
                <div className="space-y-4">
                    {lastOrder.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between text-sm">
                        <div className="flex flex-col">
                            <div className="flex items-start gap-2">
                                <span className="font-bold text-gray-900 min-w-[20px]">{item.quantity}x</span>
                                <span className="text-gray-700">{item.name}</span>
                            </div>
                        </div>
                        <span className="font-medium text-gray-900">${(item.finalPrice * item.quantity).toFixed(2)}</span>
                    </div>
                    ))}
                </div>
                <div className="border-t-2 border-dashed border-gray-100 mt-4 pt-3 space-y-2">
                    <div className="flex justify-between items-center text-lg">
                        <span className="font-bold text-gray-900">Total Paid</span>
                        <span className="font-bold text-primary">${lastOrder.total.toFixed(2)}</span>
                    </div>
                </div>
            </div>

            <button 
                onClick={() => { setOrderPlaced(false); setTableNumber(''); }}
                className="bg-gray-900 text-white px-8 py-3 rounded-full hover:bg-black transition font-bold shadow-lg active:scale-95 mb-10"
            >
                Start New Order
            </button>
        </div>
        <VirtualWaiter />
      </div>
    );
  }

  if (isWelcomeView && !loyaltyUser) {
    return (
      <div className="min-h-screen bg-primary flex flex-col items-center justify-center p-6 text-white relative overflow-hidden">
        <div className="w-full absolute top-0 left-0 bg-black/30 text-white text-[10px] md:text-xs py-1 text-center font-medium z-10">
           Website Owner: Asad Ali
        </div>
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 20% 20%, #FFC72C 2%, transparent 2.5%), radial-gradient(circle at 80% 80%, #FFC72C 2%, transparent 2.5%)', backgroundSize: '60px 60px' }}></div>
        <div className="relative z-10 w-full max-w-sm text-center animate-in slide-in-from-bottom duration-700">
           <div className="w-24 h-24 bg-accent mx-auto rounded-3xl flex items-center justify-center mb-8 shadow-2xl transform rotate-6 border-4 border-white/20">
              <span className="text-primary text-6xl font-black">M</span>
           </div>
           <h1 className="text-3xl font-black mb-2 tracking-tight">Unlock M Rewards</h1>
           <p className="text-white/80 font-medium mb-10">Earn points on every order for free food.</p>
           <div className="space-y-4">
              <button onClick={openSignIn} className="w-full bg-white text-primary py-4 rounded-xl font-black text-lg shadow-lg hover:bg-gray-100 transition active:scale-95 flex items-center justify-center gap-2">
                 <LogIn size={20} /> Sign In
              </button>
              <button onClick={openSignUp} className="w-full bg-accent text-primary py-4 rounded-xl font-black text-lg shadow-lg hover:bg-yellow-400 transition active:scale-95 flex items-center justify-center gap-2">
                 <UserPlus size={20} /> Join Now
              </button>
              <div className="pt-4">
                 <button onClick={() => setIsWelcomeView(false)} className="text-white/70 text-sm font-bold hover:text-white transition underline underline-offset-4">
                    Continue as Guest
                 </button>
              </div>
           </div>
        </div>
        <LoyaltyModal isOpen={isLoyaltyOpen} initialAuthMode={loyaltyAuthMode} onClose={() => setIsLoyaltyOpen(false)} currentUser={loyaltyUser} onLogin={handleLogin} onLogout={handleLogout} onRedeemReward={handleRedeemReward} onReorder={handleReorder} />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0 pt-6">
      <div className="w-full fixed top-0 left-0 z-40 bg-black text-white text-[10px] md:text-xs py-1 text-center font-medium">
         Website Owner: Asad Ali
      </div>

      <header className="bg-primary sticky top-6 z-30 shadow-md border-b-4 border-accent">
        <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="bg-accent w-10 h-10 rounded-lg flex items-center justify-center transform -rotate-3 shadow-md">
                <span className="text-primary font-black text-2xl">M</span>
            </div>
            <div className="leading-tight">
                <h1 className="text-white font-black text-lg tracking-tight">McDonald's</h1>
                <p className="text-white/80 text-[10px] uppercase font-bold tracking-widest">Butranwali</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
             {loyaltyUser ? (
                 <button onClick={() => setIsLoyaltyOpen(true)} className="flex items-center gap-2 bg-black/20 hover:bg-black/30 text-white px-3 py-1.5 rounded-full transition">
                     <span className="text-xs font-bold text-accent">{loyaltyUser.points} pts</span>
                     <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center"><User size={14} /></div>
                 </button>
             ) : (
                 <div className="flex gap-2">
                    <button onClick={openSignIn} className="text-white text-xs font-bold hover:underline">Sign In</button>
                    <span className="text-white/50">|</span>
                    <button onClick={openSignUp} className="text-accent text-xs font-bold hover:underline">Join</button>
                 </div>
             )}
             
             <button 
                onClick={() => setIsCartOpen(true)}
                className="relative bg-white text-primary p-2.5 rounded-full shadow-lg hover:bg-gray-100 transition active:scale-95"
             >
                <ShoppingBag size={20} />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 bg-accent text-primary text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-primary">
                    {totalItems}
                  </span>
                )}
             </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <HeroBanner promotions={promotions} />

        {personalizedOffer && (
             <div className="mb-8 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden group">
                 <div className="absolute top-0 right-0 p-8 opacity-20 transform rotate-12 group-hover:rotate-45 transition duration-700"><Sparkles size={100} /></div>
                 <div className="relative z-10 flex items-center justify-between">
                     <div>
                         <span className="bg-white/20 backdrop-blur-md text-white text-xs font-bold px-2 py-1 rounded-md mb-2 inline-block">JUST FOR YOU</span>
                         <h3 className="text-2xl font-black italic">{personalizedOffer.title}</h3>
                         <p className="text-white/80">Get 10% off your order today!</p>
                     </div>
                     <div className="bg-white text-purple-600 font-bold px-4 py-2 rounded-lg shadow-xl">
                         10% OFF
                     </div>
                 </div>
             </div>
        )}

        <div className="sticky top-[80px] z-20 bg-background/95 backdrop-blur-sm py-4 -mx-4 px-4 border-b border-gray-200 mb-6 flex items-center gap-4 overflow-x-auto no-scrollbar">
            {categories.map(category => (
                <button
                key={category}
                onClick={() => setSelectedCategory(category as Category)}
                className={`whitespace-nowrap px-5 py-2 rounded-full text-sm font-bold transition-all duration-300 shadow-sm ${
                    selectedCategory === category 
                    ? 'bg-secondary text-white scale-105 shadow-md' 
                    : 'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'
                }`}
                >
                {category}
                </button>
            ))}
        </div>

        {/* Dietary Filters */}
        <div className="flex flex-wrap gap-2 mb-6">
            <button onClick={() => toggleFilter('Vegetarian')} className={`px-3 py-1.5 rounded-lg text-xs font-bold border flex items-center gap-1 transition ${activeFilters.has('Vegetarian') ? 'bg-green-100 border-green-300 text-green-800' : 'bg-white border-gray-200 text-gray-500'}`}>
                <Leaf size={12} /> Vegetarian
            </button>
            <button onClick={() => toggleFilter('Vegan')} className={`px-3 py-1.5 rounded-lg text-xs font-bold border flex items-center gap-1 transition ${activeFilters.has('Vegan') ? 'bg-green-600 border-green-700 text-white' : 'bg-white border-gray-200 text-gray-500'}`}>
                <Leaf size={12} className="fill-current"/> Vegan
            </button>
            <button onClick={() => toggleFilter('Gluten Free')} className={`px-3 py-1.5 rounded-lg text-xs font-bold border flex items-center gap-1 transition ${activeFilters.has('Gluten Free') ? 'bg-orange-100 border-orange-300 text-orange-800' : 'bg-white border-gray-200 text-gray-500'}`}>
                <WheatOff size={12} /> Gluten Free
            </button>
        </div>

        {/* Saved Favorites */}
        {loyaltyUser && loyaltyUser.savedFavorites && loyaltyUser.savedFavorites.length > 0 && (
             <div className="mb-8">
                 <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2"><Heart size={16} className="text-primary fill-current"/> Your Favorites</h3>
                 <div className="flex gap-4 overflow-x-auto pb-2">
                     {loyaltyUser.savedFavorites.map(fav => (
                         <button 
                            key={fav.id}
                            onClick={() => addFavoriteToCart(fav)}
                            className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm min-w-[200px] text-left hover:border-primary hover:shadow-md transition group"
                         >
                             <div className="font-bold text-gray-900 group-hover:text-primary transition">{fav.name}</div>
                             <div className="text-xs text-gray-500 truncate mt-1">
                                 {fav.selectedVariant?.name || 'Regular'} 
                                 {fav.selectedModifiers && fav.selectedModifiers.length > 0 && ` + ${fav.selectedModifiers.length} mods`}
                             </div>
                             <div className="mt-3 flex items-center text-xs font-bold text-accent uppercase tracking-wide">
                                 Order Now <ArrowRight size={12} className="ml-1"/>
                             </div>
                         </button>
                     ))}
                 </div>
             </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {isLoading ? (
             <div className="col-span-full text-center py-20 text-gray-500">Loading delicious items...</div>
          ) : (
             filteredItems.map((item) => {
                // Determine if really available (Stock + Admin Switch)
                const isStockAvailable = checkMenuAvailability(item, inventory);
                // Override the item for display purposes only
                const displayItem = { ...item, available: item.available && isStockAvailable };

                return (
                    <MenuCard 
                    key={item.id} 
                    item={displayItem} 
                    onAdd={(i) => addToCart(i)}
                    onCustomize={(i) => setCustomizingItem(i)}
                    />
                );
             })
          )}
        </div>
      </main>

      {/* Cart Drawer */}
      <div 
        className={`fixed inset-0 z-50 bg-black/50 backdrop-blur-sm transition-opacity duration-300 ${isCartOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setIsCartOpen(false)}
      >
        <div 
            className={`fixed top-0 right-0 w-full max-w-md h-full bg-white shadow-2xl transform transition-transform duration-300 ease-out flex flex-col ${isCartOpen ? 'translate-x-0' : 'translate-x-full'}`}
            onClick={e => e.stopPropagation()}
        >
            <div className="bg-primary text-white p-4 flex justify-between items-center shadow-md">
                <div className="flex items-center gap-2">
                    <ShoppingBag size={20} />
                    <h2 className="font-bold text-lg">Your Order</h2>
                </div>
                <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-white/20 rounded-full transition">
                    <ChevronLeft size={24} />
                </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4">
                {cart.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-gray-400">
                        <ShoppingBag size={64} className="mb-4 opacity-20" />
                        <p className="font-medium">Your cart is empty</p>
                        <button onClick={() => setIsCartOpen(false)} className="mt-4 text-primary font-bold hover:underline">Browse Menu</button>
                    </div>
                ) : (
                    <>
                        <div className="space-y-4">
                            {cart.map((item) => (
                                <div key={item.cartId} className="flex gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100 relative group">
                                    <div className="w-16 h-16 bg-white rounded-lg overflow-hidden shrink-0 border border-gray-200">
                                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex justify-between items-start">
                                            <h4 className="font-bold text-gray-900">{item.name}</h4>
                                            <button 
                                                onClick={() => removeFromCart(item.cartId)}
                                                className="text-gray-400 hover:text-red-500 p-1"
                                            >
                                                <X size={16} />
                                            </button>
                                        </div>
                                        
                                        {item.selectedVariant && (
                                           <p className="text-xs text-gray-500">{item.selectedVariant.name}</p>
                                        )}
                                        {item.selectedModifiers && item.selectedModifiers.length > 0 && (
                                            <div className="text-xs text-gray-500 mt-1 space-y-0.5">
                                                {item.selectedModifiers.map((mod, i) => (
                                                    <span key={i} className="block">+ {mod.optionName}</span>
                                                ))}
                                            </div>
                                        )}
                                        {item.itemNote && (
                                            <p className="text-xs text-red-600 italic mt-1">"{item.itemNote}"</p>
                                        )}

                                        <div className="flex justify-between items-end mt-2">
                                            <span className="text-xs text-gray-500 font-bold bg-white px-2 py-1 rounded border">Qty: {item.quantity}</span>
                                            <div className="text-right">
                                                {item.appliedDiscount && (
                                                    <span className="block text-[10px] text-green-600 font-bold">{item.appliedDiscount.name}</span>
                                                )}
                                                <span className={`font-bold ${item.appliedDiscount ? 'text-green-600' : 'text-primary'}`}>
                                                    ${(item.finalPrice * item.quantity).toFixed(2)}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <CartUpsell cart={cart} menuItems={menuItems} onAdd={(item, discount) => addToCart(item, 1, undefined, undefined, undefined, discount)} />
                    </>
                )}
            </div>

            {cart.length > 0 && (
                <div className="bg-white border-t border-gray-100 shadow-[0_-5px_20px_rgba(0,0,0,0.05)]">
                    <div className="p-4 bg-gray-50 border-b border-gray-100">
                        {/* Checkout Type Tabs */}
                        <div className="flex bg-gray-200 p-1 rounded-lg mb-4">
                            <button 
                                onClick={() => setOrderType('dine-in')}
                                className={`flex-1 py-2 text-xs font-bold rounded-md transition ${orderType === 'dine-in' ? 'bg-white shadow text-gray-900' : 'text-gray-500'}`}
                            >
                                Dine-In
                            </button>
                            <button 
                                onClick={() => setOrderType('curbside')}
                                className={`flex-1 py-2 text-xs font-bold rounded-md transition ${orderType === 'curbside' ? 'bg-white shadow text-gray-900' : 'text-gray-500'}`}
                            >
                                Curbside
                            </button>
                             <button 
                                onClick={() => setOrderType('drive-thru')}
                                className={`flex-1 py-2 text-xs font-bold rounded-md transition ${orderType === 'drive-thru' ? 'bg-white shadow text-gray-900' : 'text-gray-500'}`}
                            >
                                Drive-Thru
                            </button>
                            <button 
                                onClick={() => setOrderType('pickup')}
                                className={`flex-1 py-2 text-xs font-bold rounded-md transition ${orderType === 'pickup' ? 'bg-white shadow text-gray-900' : 'text-gray-500'}`}
                            >
                                Schedule
                            </button>
                        </div>

                        {/* Order Type Specific Inputs */}
                        {orderType === 'dine-in' && (
                            <input 
                                type="text" 
                                placeholder="Table Number" 
                                className="w-full p-3 border border-gray-300 rounded-lg text-sm mb-3 focus:border-primary outline-none"
                                value={tableNumber}
                                onChange={(e) => setTableNumber(e.target.value)}
                            />
                        )}
                        {orderType === 'curbside' && (
                            <div className="space-y-2 mb-3">
                                <input type="text" placeholder="Car Model (e.g. Honda Civic)" className="w-full p-3 border rounded-lg text-sm" value={curbsideDetails.carModel} onChange={e => setCurbsideDetails({...curbsideDetails, carModel: e.target.value})} />
                                <div className="flex gap-2">
                                    <input type="text" placeholder="Color" className="w-1/3 p-3 border rounded-lg text-sm" value={curbsideDetails.carColor} onChange={e => setCurbsideDetails({...curbsideDetails, carColor: e.target.value})} />
                                    <input type="text" placeholder="License Plate" className="w-2/3 p-3 border rounded-lg text-sm" value={curbsideDetails.licensePlate} onChange={e => setCurbsideDetails({...curbsideDetails, licensePlate: e.target.value})} />
                                </div>
                            </div>
                        )}
                        {orderType === 'drive-thru' && (
                            <div className="mb-3 p-3 bg-gray-100 rounded-lg text-sm text-gray-600 flex items-center gap-2">
                                <Car size={16} />
                                <span>We'll guide you to the lane after order.</span>
                            </div>
                        )}
                        {orderType === 'pickup' && (
                            <input 
                                type="datetime-local" 
                                className="w-full p-3 border border-gray-300 rounded-lg text-sm mb-3"
                                value={scheduledTime}
                                onChange={(e) => setScheduledTime(e.target.value)}
                            />
                        )}

                        {/* Guest / Contact Info */}
                        {!loyaltyUser && (
                            <div className="mb-3">
                                <p className="text-xs font-bold text-gray-500 mb-1">Guest Checkout (Optional)</p>
                                <div className="grid grid-cols-2 gap-2">
                                    <input type="email" placeholder="Email" className="p-2 border rounded text-sm" value={guestContact.email} onChange={e => setGuestContact({...guestContact, email: e.target.value})} />
                                    <input type="tel" placeholder="Phone" className="p-2 border rounded text-sm" value={guestContact.phone} onChange={e => setGuestContact({...guestContact, phone: e.target.value})} />
                                </div>
                            </div>
                        )}

                        <textarea 
                            placeholder="Add a note for the kitchen..." 
                            rows={2}
                            className="w-full p-3 border border-gray-300 rounded-lg text-sm focus:border-primary outline-none resize-none bg-white"
                            value={customerNote}
                            onChange={(e) => setCustomerNote(e.target.value)}
                        />
                    </div>

                    <div className="p-6">
                        {loyaltyUser && (
                            <div className="bg-yellow-50 border border-accent p-3 rounded-lg mb-4 flex items-center gap-3">
                                <div className="bg-accent text-primary p-2 rounded-full"><Gift size={16}/></div>
                                <div className="flex-1">
                                    <p className="text-xs font-bold text-yellow-900">M Rewards</p>
                                    <p className="text-xs text-yellow-700">You'll earn <span className="font-bold">{potentialPoints} pts</span></p>
                                </div>
                                {activeReward ? (
                                    <button onClick={handleRemoveReward} className="text-xs font-bold text-red-600 hover:underline">Remove Reward</button>
                                ) : (
                                    <button onClick={() => {setIsCartOpen(false); setIsLoyaltyOpen(true);}} className="text-xs font-bold text-primary hover:underline">Redeem Pts</button>
                                )}
                            </div>
                        )}

                        <div className="space-y-2 mb-6">
                            <div className="flex justify-between text-gray-600">
                                <span>Subtotal</span>
                                <span>${subtotal.toFixed(2)}</span>
                            </div>
                            {activeReward && (
                                <div className="flex justify-between text-green-600 font-medium animate-in slide-in-from-right">
                                    <span className="flex items-center gap-1"><Tag size={14}/> {activeReward.name}</span>
                                    <span>-${activeReward.discountAmount?.toFixed(2)}</span>
                                </div>
                            )}
                            <div className="flex justify-between text-xl font-bold text-gray-900 pt-2 border-t">
                                <span>Total</span>
                                <span>${total.toFixed(2)}</span>
                            </div>
                        </div>

                        <button 
                            onClick={handleCheckout}
                            className="w-full bg-primary text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:bg-red-700 transition transform active:scale-[0.98]"
                        >
                            Place Order
                        </button>
                    </div>
                </div>
            )}
        </div>
      </div>

      <VirtualWaiter />
      
      {customizingItem && (
        <ProductCustomizer 
          item={customizingItem}
          onClose={() => setCustomizingItem(null)}
          onAddToCart={addToCart}
        />
      )}

      <LoyaltyModal 
        isOpen={isLoyaltyOpen}
        initialAuthMode={loyaltyAuthMode}
        onClose={() => setIsLoyaltyOpen(false)}
        currentUser={loyaltyUser}
        onLogin={handleLogin}
        onLogout={handleLogout}
        onRedeemReward={handleRedeemReward}
        onReorder={handleReorder}
      />
    </div>
  );
};

export default CustomerApp;
