
import React, { useState, useEffect, useRef } from 'react';
import { MenuItem, Category, Order, OrderStatus, Promotion } from '../types';
import { getMenuItems, saveMenuItem, deleteMenuItem, getOrders, updateOrderStatus, getPromotions, savePromotion, deletePromotion } from '../services/storageService';
import { Plus, Edit2, Trash2, X, Save, ClipboardList, CheckCircle, XCircle, Clock, MessageSquare, Search, ShoppingBag, AlertCircle, BellRing, Heart, Tag, Leaf, WheatOff, FileDown, Car, Calendar, DollarSign, RefreshCcw, AlertTriangle, ChefHat, Eye, EyeOff } from 'lucide-react';
import { jsPDF } from 'jspdf';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'menu' | 'orders' | 'promos'>('orders');
  
  // Menu State
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [isMenuLoading, setIsMenuLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Partial<MenuItem>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  // Orders State
  const [orders, setOrders] = useState<Order[]>([]);
  const [isOrdersLoading, setIsOrdersLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Promotions State
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [isPromosLoading, setIsPromosLoading] = useState(true);
  const [isPromoModalOpen, setIsPromoModalOpen] = useState(false);
  const [editingPromo, setEditingPromo] = useState<Partial<Promotion>>({});

  // Notification State
  const [toast, setToast] = useState<{title: string, msg: string} | null>(null);
  const knownOrderIds = useRef<Set<string>>(new Set());
  const initialLoadComplete = useRef(false);
  const toastTimeout = useRef<number | null>(null);

  useEffect(() => {
    if (activeTab === 'menu') {
      loadMenuItems();
    } else if (activeTab === 'promos') {
      loadPromotions();
    } else {
      loadOrders();
      const interval = setInterval(loadOrders, 5000);
      return () => clearInterval(interval);
    }
  }, [activeTab]);

  // --- Menu Logic ---
  const loadMenuItems = async () => {
    setIsMenuLoading(true);
    const data = await getMenuItems();
    setMenuItems(data);
    setIsMenuLoading(false);
  };

  const handleAddNewItem = () => {
    setEditingItem({
      id: '',
      name: '',
      description: '',
      price: 0,
      category: Category.BURGER,
      image: '',
      tags: [],
      available: true,
      isFavorite: false,
      dietaryInfo: { isVegetarian: false, isVegan: false, isGlutenFree: false, allergens: [] }
    });
    setIsModalOpen(true);
  };

  const handleEditItem = (item: MenuItem) => {
    setEditingItem({ ...item, dietaryInfo: item.dietaryInfo || { isVegetarian: false, isVegan: false, isGlutenFree: false, allergens: [] } });
    setIsModalOpen(true);
  };

  const handleDeleteItem = async (id: string) => {
    if (window.confirm("Are you sure you want to delete this item?")) {
      await deleteMenuItem(id);
      loadMenuItems();
    }
  };

  const handleToggleAvailability = async (e: React.MouseEvent, item: MenuItem) => {
    e.stopPropagation();
    const updatedItem = { ...item, available: !item.available };
    setMenuItems(prev => prev.map(i => i.id === item.id ? updatedItem : i));
    await saveMenuItem(updatedItem);
  };

  const handleToggleFavorite = async (item: MenuItem) => {
    const updatedItem = { ...item, isFavorite: !item.isFavorite };
    setMenuItems(prev => prev.map(i => i.id === item.id ? updatedItem : i));
    await saveMenuItem(updatedItem);
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem.name || editingItem.price === undefined) return;
    
    setIsSaving(true);
    
    const itemToSave: MenuItem = {
      id: editingItem.id || Math.random().toString(36).substr(2, 9),
      name: editingItem.name || 'Untitled',
      description: editingItem.description || '',
      price: Number(editingItem.price),
      category: editingItem.category || Category.BURGER,
      image: editingItem.image || '',
      tags: typeof editingItem.tags === 'string' 
        ? (editingItem.tags as string).split(',').map((t:string) => t.trim()).filter(Boolean) 
        : (editingItem.tags || []),
      available: editingItem.available !== undefined ? editingItem.available : true,
      isFavorite: editingItem.isFavorite || false,
      variants: editingItem.variants, 
      customizationGroups: editingItem.customizationGroups,
      dietaryInfo: editingItem.dietaryInfo
    };

    await saveMenuItem(itemToSave);
    setIsSaving(false);
    setIsModalOpen(false);
    loadMenuItems();
  };

  // --- Promotion Logic ---
  const loadPromotions = async () => {
    setIsPromosLoading(true);
    const data = await getPromotions();
    setPromotions(data);
    setIsPromosLoading(false);
  };

  const handleAddPromo = () => {
    setEditingPromo({
      id: '',
      title: '',
      description: '',
      imageUrl: '',
      discountPercent: 10,
      targetCategory: 'All',
      endDate: Date.now() + 86400000,
      isActive: true
    });
    setIsPromoModalOpen(true);
  };

  const handleEditPromo = (promo: Promotion) => {
    setEditingPromo({ ...promo });
    setIsPromoModalOpen(true);
  };

  const handleDeletePromo = async (id: string) => {
    if (window.confirm("Delete this promotion?")) {
      await deletePromotion(id);
      loadPromotions();
    }
  };

  const handleSavePromo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPromo.title) return;

    setIsSaving(true);
    const promoToSave: Promotion = {
      id: editingPromo.id || Math.random().toString(36).substr(2, 9),
      title: editingPromo.title || 'Untitled Promo',
      description: editingPromo.description || '',
      imageUrl: editingPromo.imageUrl || '',
      discountPercent: Number(editingPromo.discountPercent),
      targetCategory: editingPromo.targetCategory || 'All',
      endDate: Number(editingPromo.endDate),
      isActive: editingPromo.isActive !== undefined ? editingPromo.isActive : true
    };
    
    await savePromotion(promoToSave);
    setIsSaving(false);
    setIsPromoModalOpen(false);
    loadPromotions();
  };

  // --- Order Logic ---
  const loadOrders = async () => {
    const data = await getOrders();
    
    if (!initialLoadComplete.current) {
        data.forEach(o => knownOrderIds.current.add(o.id));
        initialLoadComplete.current = true;
    } else {
        const newOrders = data.filter(o => !knownOrderIds.current.has(o.id));
        if (newOrders.length > 0) {
            newOrders.forEach(o => knownOrderIds.current.add(o.id));
            const count = newOrders.length;
            
            // Play Sound Alert
            try {
                const audio = new Audio('https://codeskulptor-demos.commondatastorage.googleapis.com/pang/pop.mp3');
                audio.volume = 0.5;
                audio.play().catch(e => console.log('Audio autoplay blocked', e));
            } catch (e) {
                // Ignore audio errors
            }

            setToast({
                title: 'New Order Received!',
                msg: count > 1 ? `${count} new orders` : `Total: $${newOrders[0].total.toFixed(2)}`
            });
            
            if (toastTimeout.current) clearTimeout(toastTimeout.current);
            // Replaced NodeJS.Timeout with number
            toastTimeout.current = window.setTimeout(() => setToast(null), 5000);
        }
    }

    const sorted = data.sort((a, b) => {
      if (a.status === OrderStatus.PENDING && b.status !== OrderStatus.PENDING) return -1;
      return b.timestamp - a.timestamp;
    });
    setOrders(sorted);
    setIsOrdersLoading(false);
  };

  const handleApproveOrder = async (orderId: string) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: OrderStatus.PREPARING } : o));
    await updateOrderStatus(orderId, OrderStatus.PREPARING);
  };

  const handleRejectOrder = async (orderId: string) => {
    const reason = window.prompt("Please enter a reason for cancellation:", "Item unavailable");
    if (reason !== null) { 
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: OrderStatus.CANCELLED, cancellationReason: reason } : o));
      await updateOrderStatus(orderId, OrderStatus.CANCELLED, reason);
    }
  };

  const handleMarkPaid = async (orderId: string) => {
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: OrderStatus.PAID } : o));
      await updateOrderStatus(orderId, OrderStatus.PAID);
  };

  const handleMarkFailed = async (orderId: string) => {
      const reason = window.prompt("Enter reason for payment failure:", "Card declined");
      if (reason !== null) {
          setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: OrderStatus.FAILED, cancellationReason: reason } : o));
          await updateOrderStatus(orderId, OrderStatus.FAILED, reason);
      }
  };

  const handleMarkRefunded = async (orderId: string) => {
      const reason = window.prompt("Enter reason for refund:", "Customer complaint");
      if (reason !== null) {
          setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: OrderStatus.REFUNDED, cancellationReason: reason } : o));
          await updateOrderStatus(orderId, OrderStatus.REFUNDED, reason);
      }
  };

  const handleExportPDF = (order: Order) => {
    try {
      const doc = new jsPDF();
      doc.setFontSize(22);
      doc.setTextColor(218, 41, 28);
      doc.text("McDonald's", 105, 15, { align: "center" });
      doc.setFontSize(10);
      doc.setTextColor(0, 0, 0);
      doc.text("Butranwali Gujranwala", 105, 20, { align: "center" });
      
      doc.setFontSize(16);
      doc.text("Order Receipt", 105, 30, { align: "center" });
      
      doc.setFontSize(10);
      doc.text(`Order ID: ${order.id}`, 20, 45);
      doc.text(`Date: ${new Date(order.timestamp).toLocaleString()}`, 20, 50);
      doc.text(`Type: ${order.orderType.toUpperCase()}`, 20, 55);
      doc.text(`Status: ${order.status}`, 20, 60);

      doc.line(20, 70, 190, 70);
      
      let yPos = 80;
      doc.text("Item", 20, yPos);
      doc.text("Qty", 140, yPos);
      doc.text("Price", 170, yPos);
      yPos += 8;

      order.items.forEach((item) => {
        const name = item.name;
        const qty = item.quantity.toString();
        const price = `$${(item.finalPrice * item.quantity).toFixed(2)}`;
        doc.text(name, 20, yPos);
        doc.text(qty, 140, yPos);
        doc.text(price, 170, yPos);
        yPos += 8;
      });

      doc.text(`Total: $${order.total.toFixed(2)}`, 190, yPos + 10, { align: "right" });
      doc.save(`Order_${order.id}.pdf`);
      setToast({ title: "Success", msg: "PDF exported successfully!" });
      if (toastTimeout.current) clearTimeout(toastTimeout.current);
      toastTimeout.current = window.setTimeout(() => setToast(null), 3000);
    } catch (error) {
        console.error("PDF Export Error:", error);
        alert("Failed to export PDF. Please try again.");
    }
  };

  const getStatusBadge = (status: OrderStatus) => {
    let colorClass = 'bg-gray-100 text-gray-800 border-gray-200';
    let icon = null;

    switch (status) {
      case OrderStatus.PENDING:
        colorClass = 'bg-yellow-100 text-yellow-800 border-yellow-200';
        icon = <Clock size={14} />;
        break;
      case OrderStatus.PREPARING:
        colorClass = 'bg-blue-100 text-blue-800 border-blue-200';
        icon = <ChefHat size={14} />;
        break;
      case OrderStatus.READY:
        colorClass = 'bg-purple-100 text-purple-800 border-purple-200';
        icon = <BellRing size={14} />;
        break;
      case OrderStatus.SERVED:
        colorClass = 'bg-indigo-100 text-indigo-800 border-indigo-200';
        icon = <CheckCircle size={14} />;
        break;
      case OrderStatus.PAID:
        colorClass = 'bg-green-100 text-green-700 border-green-200 shadow-sm';
        icon = <DollarSign size={14} className="stroke-[3px]" />;
        break;
      case OrderStatus.FAILED:
        colorClass = 'bg-red-100 text-red-700 border-red-200';
        icon = <AlertCircle size={14} />;
        break;
      case OrderStatus.REFUNDED:
        colorClass = 'bg-orange-100 text-orange-700 border-orange-200';
        icon = <RefreshCcw size={14} />;
        break;
      case OrderStatus.CANCELLED:
        colorClass = 'bg-gray-100 text-gray-500 border-gray-200';
        icon = <XCircle size={14} />;
        break;
    }

    return (
      <span className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold border mt-1 ${colorClass}`}>
        {icon}
        {status}
      </span>
    );
  };

  const filteredOrders = orders.filter(order => {
    const query = searchQuery.toLowerCase();
    return (
      order.id.toLowerCase().includes(query) ||
      (order.tableNumber && order.tableNumber.toLowerCase().includes(query)) ||
      (order.curbsideDetails && order.curbsideDetails.licensePlate.toLowerCase().includes(query))
    );
  });

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center h-16">
          <div className="flex items-center gap-2">
             <div className="bg-primary text-white p-2 rounded-lg"><ClipboardList size={20}/></div>
             <h1 className="text-xl font-bold text-gray-900">Admin Dashboard</h1>
          </div>
          <div className="flex bg-gray-100 p-1 rounded-lg">
             <button onClick={() => setActiveTab('orders')} className={`px-3 py-2 rounded ${activeTab === 'orders' ? 'bg-white shadow' : ''}`}>Orders</button>
             <button onClick={() => setActiveTab('menu')} className={`px-3 py-2 rounded ${activeTab === 'menu' ? 'bg-white shadow' : ''}`}>Menu</button>
             <button onClick={() => setActiveTab('promos')} className={`px-3 py-2 rounded ${activeTab === 'promos' ? 'bg-white shadow' : ''}`}>Promotions</button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6 w-full">
        {activeTab === 'orders' && (
          <div className="space-y-6">
             <div className="flex justify-between items-center">
                 <h2 className="text-2xl font-bold">Incoming Orders</h2>
                 <input 
                    type="text" 
                    placeholder="Search Order..." 
                    value={searchQuery} 
                    onChange={e => setSearchQuery(e.target.value)}
                    className="border p-2 rounded-lg"
                 />
             </div>
             {filteredOrders.map(order => (
                 <div key={order.id} className={`bg-white rounded-xl shadow-sm border border-gray-200 p-6 ${order.status === OrderStatus.CANCELLED || order.status === OrderStatus.FAILED ? 'opacity-70 bg-gray-50' : ''}`}>
                     <div className="flex justify-between items-start mb-4">
                         <div>
                             <h3 className="text-xl font-bold flex items-center gap-2">
                                 {order.orderType === 'dine-in' ? `Table ${order.tableNumber}` : order.orderType.toUpperCase()}
                                 {order.orderType === 'curbside' && <Car size={16}/>}
                                 {order.orderType === 'drive-thru' && <Car size={16} className="text-red-500"/>}
                             </h3>
                             <p className="text-gray-500 text-sm">#{order.id} • {new Date(order.timestamp).toLocaleString()}</p>
                             {order.curbsideDetails && (
                                 <p className="text-blue-600 font-bold text-sm mt-1">Car: {order.curbsideDetails.carModel} ({order.curbsideDetails.carColor}) - {order.curbsideDetails.licensePlate}</p>
                             )}
                             {order.scheduledTime && (
                                 <p className="text-orange-600 font-bold text-sm mt-1">Scheduled: {new Date(order.scheduledTime).toLocaleString()}</p>
                             )}
                             {order.guestContact && (order.guestContact.email || order.guestContact.phone) && (
                                 <p className="text-gray-500 text-sm mt-1">Contact: {order.guestContact.email} {order.guestContact.phone}</p>
                             )}
                         </div>
                         <div className="text-right">
                             <div className="text-2xl font-bold flex items-center justify-end gap-2">
                                 ${order.total.toFixed(2)}
                                 <span className="bg-gray-100 text-gray-900 text-xs px-2 py-1 rounded-full flex items-center gap-1">
                                     <ShoppingBag size={12}/> {order.items.reduce((sum, i) => sum + i.quantity, 0)} items
                                 </span>
                             </div>
                             {getStatusBadge(order.status)}
                             <button onClick={() => handleExportPDF(order)} className="block mt-2 text-xs text-primary font-bold hover:underline ml-auto">Export PDF</button>
                         </div>
                     </div>
                     <div className="border-t pt-4">
                         {order.items.map((item, idx) => (
                             <div key={idx} className="flex gap-2 text-sm mb-1">
                                 <span className="font-bold">{item.quantity}x</span>
                                 <span>{item.name}</span>
                                 {item.itemNote && <span className="text-red-500 italic"> - {item.itemNote}</span>}
                             </div>
                         ))}
                     </div>
                     
                     {(order.customerNote) && (
                         <div className="mt-3 bg-yellow-50 p-2 rounded border border-yellow-100 text-sm text-yellow-800 flex gap-2 items-start">
                             <MessageSquare size={16} className="shrink-0 mt-0.5" />
                             <span className="font-bold">Note: {order.customerNote}</span>
                         </div>
                     )}

                     {(order.status === OrderStatus.CANCELLED || order.status === OrderStatus.FAILED || order.status === OrderStatus.REFUNDED) && order.cancellationReason && (
                         <div className="mt-3 bg-red-50 p-2 rounded border border-red-100 text-sm text-red-800 flex gap-2 items-start">
                             <AlertCircle size={16} className="shrink-0 mt-0.5" />
                             <span><strong>Reason:</strong> {order.cancellationReason}</span>
                         </div>
                     )}

                     <div className="mt-4 flex flex-wrap gap-2 pt-4 border-t border-gray-100">
                         {order.status === OrderStatus.PENDING && (
                             <>
                                 <button onClick={() => handleRejectOrder(order.id)} className="px-4 py-2 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg font-bold text-sm transition">Reject</button>
                                 <button onClick={() => handleApproveOrder(order.id)} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-sm transition">Approve</button>
                             </>
                         )}
                         
                         {/* Payment & Status Actions */}
                         {order.status !== OrderStatus.CANCELLED && order.status !== OrderStatus.REFUNDED && order.status !== OrderStatus.FAILED && (
                             <div className="flex gap-2 ml-auto">
                                 {order.status !== OrderStatus.PAID && (
                                     <>
                                        <button onClick={() => handleMarkFailed(order.id)} className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg font-bold text-xs flex items-center gap-1 transition">
                                            <AlertTriangle size={14} /> Mark Failed
                                        </button>
                                        <button onClick={() => handleMarkPaid(order.id)} className="px-3 py-2 bg-green-50 hover:bg-green-100 text-green-700 rounded-lg font-bold text-xs flex items-center gap-1 transition">
                                            <DollarSign size={14} /> Mark Paid
                                        </button>
                                     </>
                                 )}
                                 {order.status === OrderStatus.PAID && (
                                     <button onClick={() => handleMarkRefunded(order.id)} className="px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg font-bold text-xs flex items-center gap-1 transition">
                                         <RefreshCcw size={14} /> Refund
                                     </button>
                                 )}
                             </div>
                         )}
                     </div>
                 </div>
             ))}
          </div>
        )}
        
        {activeTab === 'menu' && (
             <div className="space-y-6">
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-4">
                        <h2 className="text-2xl font-bold">Menu Management</h2>
                        <button 
                            onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
                            className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold border transition ${showFavoritesOnly ? 'bg-primary text-white border-primary' : 'bg-white text-gray-500 border-gray-300'}`}
                        >
                            <Heart size={12} className={showFavoritesOnly ? "fill-current" : ""} /> Favorites Only
                        </button>
                    </div>
                    <button onClick={handleAddNewItem} className="bg-primary hover:bg-red-700 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2">
                        <Plus size={18} /> Add Item
                    </button>
                </div>
                 
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                     {menuItems.filter(i => showFavoritesOnly ? i.isFavorite : true).map(item => (
                         <div key={item.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden group relative">
                             <div className={`relative h-40 transition-opacity ${!item.available ? 'opacity-70' : ''}`}>
                                 <img src={item.image} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                 {!item.available && (
                                     <div className="absolute inset-0 bg-black/40 flex items-center justify-center z-0">
                                         <div className="bg-red-600 text-white px-2 py-1 rounded text-xs font-bold shadow-md transform -rotate-12 border border-white/20">UNAVAILABLE</div>
                                     </div>
                                 )}
                                 <div className="absolute top-2 right-2 flex gap-1 z-10">
                                     <button 
                                        onClick={() => handleToggleFavorite(item)}
                                        className="bg-white/80 hover:bg-white p-2 rounded-full text-primary shadow-sm backdrop-blur-sm transition"
                                     >
                                         <Heart size={16} className={item.isFavorite ? "fill-current" : ""} />
                                     </button>
                                 </div>
                                 {/* Visibility Toggle Overlay */}
                                 <div className="absolute bottom-2 right-2 z-10">
                                     <button 
                                        onClick={(e) => handleToggleAvailability(e, item)}
                                        className={`flex items-center gap-2 px-3 py-1.5 rounded-full backdrop-blur-md shadow-lg border border-white/20 transition-all ${
                                            item.available 
                                            ? 'bg-green-600/90 text-white hover:bg-green-700' 
                                            : 'bg-red-600/90 text-white hover:bg-red-700'
                                        }`}
                                     >
                                         {item.available ? <Eye size={12}/> : <EyeOff size={12}/>}
                                         <span className="text-[10px] font-bold uppercase tracking-wider">{item.available ? 'Active' : 'Hidden'}</span>
                                     </button>
                                 </div>
                             </div>
                             <div className="p-4">
                                 <div className="flex justify-between items-start mb-2">
                                     <h3 className="font-bold text-gray-900 truncate pr-2">{item.name}</h3>
                                     <span className="text-sm font-bold text-primary">${item.price}</span>
                                 </div>
                                 <div className="flex justify-between mt-4 border-t pt-3">
                                     <button onClick={() => handleDeleteItem(item.id)} className="text-red-500 hover:text-red-700 p-2"><Trash2 size={18}/></button>
                                     <button onClick={() => handleEditItem(item)} className="text-blue-600 hover:text-blue-800 p-2"><Edit2 size={18}/></button>
                                 </div>
                             </div>
                         </div>
                     ))}
                 </div>
             </div>
        )}

        {activeTab === 'promos' && (
             <div className="space-y-6">
                 <div className="flex justify-between items-center">
                     <h2 className="text-2xl font-bold">Promotions</h2>
                     <button onClick={handleAddPromo} className="bg-primary hover:bg-red-700 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2">
                         <Plus size={18} /> Add Promo
                     </button>
                 </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                     {promotions.map(promo => (
                         <div key={promo.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                             <div className="h-32 bg-cover bg-center" style={{backgroundImage: `url('${promo.imageUrl}')`}}></div>
                             <div className="p-4">
                                 <div className="flex justify-between items-start">
                                     <h3 className="font-bold text-lg">{promo.title}</h3>
                                     <span className="bg-accent text-primary px-2 py-1 rounded text-xs font-bold">{promo.discountPercent}% OFF</span>
                                 </div>
                                 <p className="text-sm text-gray-500 mt-1 line-clamp-2">{promo.description}</p>
                                 <div className="flex justify-between mt-4 items-center">
                                     <span className={`text-xs font-bold ${promo.isActive ? 'text-green-600' : 'text-gray-400'}`}>
                                         {promo.isActive ? 'Active' : 'Inactive'}
                                     </span>
                                     <div className="flex gap-2">
                                         <button onClick={() => handleDeletePromo(promo.id)} className="text-gray-400 hover:text-red-500"><Trash2 size={16}/></button>
                                         <button onClick={() => handleEditPromo(promo)} className="text-blue-600 hover:text-blue-800"><Edit2 size={16}/></button>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     ))}
                 </div>
             </div>
        )}
        
        {toast && (
            <div className="fixed bottom-6 right-6 bg-gray-900 text-white p-4 rounded-xl shadow-2xl flex items-center gap-4 animate-in slide-in-from-bottom z-50">
                <div className="bg-accent text-primary p-2 rounded-full"><BellRing size={20} /></div>
                <div><h4 className="font-bold">{toast.title}</h4><p className="text-xs">{toast.msg}</p></div>
                <button onClick={() => setToast(null)} className="ml-2 text-gray-400 hover:text-white"><X size={16}/></button>
            </div>
        )}
      </main>

      {/* Item Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl p-8 w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
             <div className="flex justify-between items-center mb-6">
                 <h2 className="font-bold text-2xl text-gray-900">{editingItem.id ? 'Edit Item' : 'New Item'}</h2>
                 <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-full"><X size={24}/></button>
             </div>
             
             <form onSubmit={handleSaveItem} className="space-y-4">
                 <div className="grid grid-cols-2 gap-4">
                     <div>
                         <label className="block text-sm font-bold text-gray-700 mb-1">Item Name</label>
                         <input className="border-2 border-gray-200 p-3 rounded-lg w-full focus:border-primary focus:outline-none" value={editingItem.name || ''} onChange={e => setEditingItem({...editingItem, name: e.target.value})} placeholder="e.g. Big Mac"/>
                     </div>
                     <div>
                         <label className="block text-sm font-bold text-gray-700 mb-1">Price ($)</label>
                         <input className="border-2 border-gray-200 p-3 rounded-lg w-full focus:border-primary focus:outline-none" type="number" step="0.01" value={editingItem.price || ''} onChange={e => setEditingItem({...editingItem, price: parseFloat(e.target.value)})} placeholder="0.00"/>
                     </div>
                 </div>

                 <div>
                     <label className="block text-sm font-bold text-gray-700 mb-1">Description</label>
                     <textarea className="border-2 border-gray-200 p-3 rounded-lg w-full focus:border-primary focus:outline-none" rows={3} value={editingItem.description || ''} onChange={e => setEditingItem({...editingItem, description: e.target.value})} placeholder="Describe the deliciousness..."/>
                 </div>

                 <div className="grid grid-cols-2 gap-4">
                     <div>
                         <label className="block text-sm font-bold text-gray-700 mb-1">Category</label>
                         <select className="border-2 border-gray-200 p-3 rounded-lg w-full" value={editingItem.category} onChange={e => setEditingItem({...editingItem, category: e.target.value as Category})}>
                             {Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}
                         </select>
                     </div>
                     <div>
                         <label className="block text-sm font-bold text-gray-700 mb-1">Image URL</label>
                         <input className="border-2 border-gray-200 p-3 rounded-lg w-full focus:border-primary focus:outline-none" value={editingItem.image || ''} onChange={e => setEditingItem({...editingItem, image: e.target.value})} placeholder="https://..."/>
                     </div>
                 </div>

                 {/* Dietary Info */}
                 <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                     <label className="block text-sm font-bold text-gray-700 mb-2">Dietary Information</label>
                     <div className="flex gap-4 mb-3">
                         <label className="flex items-center gap-2 cursor-pointer bg-white px-3 py-2 rounded-lg border shadow-sm">
                             <input 
                                type="checkbox" 
                                checked={editingItem.dietaryInfo?.isVegetarian || false}
                                onChange={e => setEditingItem({...editingItem, dietaryInfo: {...editingItem.dietaryInfo!, isVegetarian: e.target.checked}})}
                             />
                             <span className="text-sm font-bold flex items-center gap-1"><Leaf size={14} className="text-green-600"/> Vegetarian</span>
                         </label>
                         <label className="flex items-center gap-2 cursor-pointer bg-white px-3 py-2 rounded-lg border shadow-sm">
                             <input 
                                type="checkbox" 
                                checked={editingItem.dietaryInfo?.isVegan || false}
                                onChange={e => setEditingItem({...editingItem, dietaryInfo: {...editingItem.dietaryInfo!, isVegan: e.target.checked}})}
                             />
                             <span className="text-sm font-bold flex items-center gap-1"><Leaf size={14} className="text-green-800"/> Vegan</span>
                         </label>
                         <label className="flex items-center gap-2 cursor-pointer bg-white px-3 py-2 rounded-lg border shadow-sm">
                             <input 
                                type="checkbox" 
                                checked={editingItem.dietaryInfo?.isGlutenFree || false}
                                onChange={e => setEditingItem({...editingItem, dietaryInfo: {...editingItem.dietaryInfo!, isGlutenFree: e.target.checked}})}
                             />
                             <span className="text-sm font-bold flex items-center gap-1"><WheatOff size={14} className="text-orange-500"/> Gluten Free</span>
                         </label>
                     </div>
                     <div>
                         <label className="block text-xs font-bold text-gray-500 mb-1">Allergens (comma separated)</label>
                         <input 
                            className="border p-2 rounded w-full text-sm" 
                            value={editingItem.dietaryInfo?.allergens?.join(', ') || ''} 
                            onChange={e => setEditingItem({...editingItem, dietaryInfo: {...editingItem.dietaryInfo!, allergens: e.target.value.split(',').map(s => s.trim()).filter(Boolean)}})}
                            placeholder="e.g. Dairy, Nuts, Soy"
                         />
                     </div>
                 </div>
                 
                 <div className="flex items-center gap-3 pt-2">
                     <label className="flex items-center gap-2 cursor-pointer">
                         <input type="checkbox" checked={editingItem.available} onChange={e => setEditingItem({...editingItem, available: e.target.checked})} className="w-5 h-5 accent-primary"/>
                         <span className="font-medium text-gray-900">Available for Ordering</span>
                     </label>
                 </div>

                 <div className="flex gap-3 mt-8 pt-4 border-t">
                     <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-3 bg-gray-100 font-bold text-gray-600 rounded-xl hover:bg-gray-200 transition">Cancel</button>
                     <button type="submit" disabled={isSaving} className="flex-1 py-3 bg-primary text-white font-bold rounded-xl shadow-lg hover:bg-red-700 transition flex items-center justify-center gap-2">
                         {isSaving ? 'Saving...' : <><Save size={20}/> Save Item</>}
                     </button>
                 </div>
             </form>
          </div>
        </div>
      )}

      {/* Promo Modal */}
      {isPromoModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="bg-white rounded-2xl p-8 w-full max-w-md shadow-2xl">
             <h2 className="font-bold text-2xl mb-4">Manage Promotion</h2>
             <form onSubmit={handleSavePromo} className="space-y-4">
                 <input className="border p-2 w-full rounded" value={editingPromo.title || ''} onChange={e => setEditingPromo({...editingPromo, title: e.target.value})} placeholder="Promo Title"/>
                 <textarea className="border p-2 w-full rounded" rows={2} value={editingPromo.description || ''} onChange={e => setEditingPromo({...editingPromo, description: e.target.value})} placeholder="Description"/>
                 <div className="flex gap-2">
                     <input className="border p-2 w-full rounded" type="number" value={editingPromo.discountPercent || ''} onChange={e => setEditingPromo({...editingPromo, discountPercent: parseFloat(e.target.value)})} placeholder="Discount %"/>
                     <select className="border p-2 w-full rounded" value={editingPromo.targetCategory} onChange={e => setEditingPromo({...editingPromo, targetCategory: e.target.value as any})}>
                         <option value="All">All Categories</option>
                         {Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}
                     </select>
                 </div>
                 <input className="border p-2 w-full rounded" value={editingPromo.imageUrl || ''} onChange={e => setEditingPromo({...editingPromo, imageUrl: e.target.value})} placeholder="Image URL"/>
                 <button type="submit" className="w-full bg-primary text-white py-3 rounded-lg font-bold">Save Promotion</button>
                 <button type="button" onClick={() => setIsPromoModalOpen(false)} className="w-full text-gray-500 py-2">Cancel</button>
             </form>
          </div>
        </div>
      )}

    </div>
  );
};

export default AdminDashboard;
