import React, { useState, useEffect } from 'react';
import { Promotion } from '../types';
import { Clock, Tag } from 'lucide-react';

interface HeroBannerProps {
  promotions: Promotion[];
}

const HeroBanner: React.FC<HeroBannerProps> = ({ promotions }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState('');

  const activePromotions = promotions.filter(p => p.isActive && p.endDate > Date.now());

  useEffect(() => {
    if (activePromotions.length === 0) return;

    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % activePromotions.length);
    }, 8000); // Rotate every 8 seconds

    return () => clearInterval(interval);
  }, [activePromotions.length]);

  useEffect(() => {
    if (activePromotions.length === 0) return;

    const timer = setInterval(() => {
      const now = Date.now();
      const end = activePromotions[currentIndex].endDate;
      const diff = end - now;

      if (diff <= 0) {
        setTimeLeft('Expired');
      } else {
        const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const minutes = Math.floor((diff / 1000 / 60) % 60);
        const seconds = Math.floor((diff / 1000) % 60);
        
        if (days > 0) {
            setTimeLeft(`${days}d ${hours}h ${minutes}m`);
        } else {
            setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
        }
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [currentIndex, activePromotions]);

  if (activePromotions.length === 0) return null;

  const currentPromo = activePromotions[currentIndex];

  return (
    <div className="relative w-full h-48 md:h-64 rounded-2xl overflow-hidden shadow-lg mb-8 group z-0">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
        style={{ backgroundImage: `url('${currentPromo.imageUrl}')` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent"></div>
      </div>

      {/* Content */}
      <div className="absolute inset-0 p-6 md:p-10 flex flex-col justify-center max-w-2xl text-white">
        <div className="flex items-center gap-2 mb-2 animate-in slide-in-from-left duration-500">
           <span className="bg-accent text-primary px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest flex items-center gap-1">
             <Tag size={12} /> Limited Time Offer
           </span>
        </div>
        
        <h2 className="text-3xl md:text-5xl font-black mb-2 leading-tight tracking-tight animate-in slide-in-from-bottom duration-500 delay-100">
          {currentPromo.title}
        </h2>
        
        <p className="text-white/90 font-medium mb-6 text-sm md:text-lg animate-in slide-in-from-bottom duration-500 delay-200">
          {currentPromo.description}
        </p>
        
        <div className="flex items-center gap-3 animate-in slide-in-from-bottom duration-500 delay-300">
           <div className="flex items-center gap-2 bg-white/20 backdrop-blur-md px-4 py-2 rounded-lg border border-white/10">
              <Clock className="text-accent" size={20} />
              <div>
                 <span className="block text-[10px] text-white/70 uppercase font-bold">Ends In</span>
                 <span className="font-mono font-bold text-lg leading-none">{timeLeft}</span>
              </div>
           </div>
           {currentPromo.discountPercent > 0 && (
              <div className="bg-primary px-4 py-2 rounded-lg font-bold shadow-lg transform rotate-[-2deg]">
                 {currentPromo.discountPercent}% OFF
              </div>
           )}
        </div>
      </div>

      {/* Indicators */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
        {activePromotions.map((_, idx) => (
          <button 
            key={idx}
            onClick={() => setCurrentIndex(idx)}
            className={`w-2 h-2 rounded-full transition-all ${idx === currentIndex ? 'bg-white w-6' : 'bg-white/50 hover:bg-white'}`}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroBanner;