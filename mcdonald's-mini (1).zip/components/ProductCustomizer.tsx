
import React, { useState, useEffect } from 'react';
import { MenuItem, Variant, CustomizationGroup, Modifier, SelectedModifier, LoyaltyUser } from '../types';
import { X, Plus, Minus, Check, MessageSquare, Heart } from 'lucide-react';
import { saveUserFavorite, getLoyaltyAccount } from '../services/storageService';

interface ProductCustomizerProps {
  item: MenuItem;
  onClose: () => void;
  onAddToCart: (item: MenuItem, quantity: number, variant?: Variant, modifiers?: SelectedModifier[], itemNote?: string) => void;
}

const ProductCustomizer: React.FC<ProductCustomizerProps> = ({ item, onClose, onAddToCart }) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState<Variant | undefined>(
    item.variants && item.variants.length > 0 ? item.variants[0] : undefined
  );
  const [itemNote, setItemNote] = useState('');
  const [selections, setSelections] = useState<Record<string, string[]>>({});
  
  // Favorites Logic
  const [currentUser, setCurrentUser] = useState<LoyaltyUser | null>(null);
  const [isFavoriteSaved, setIsFavoriteSaved] = useState(false);

  useEffect(() => {
    // Check if user is logged in
    const phone = localStorage.getItem('mcd_loyalty_phone');
    if (phone) {
        getLoyaltyAccount(phone).then(user => setCurrentUser(user));
    }

    const initialSelections: Record<string, string[]> = {};
    item.customizationGroups?.forEach(group => {
      if (group.type === 'single' && group.minSelection === 1 && group.options.length > 0) {
        initialSelections[group.id] = [group.options[0].id];
      } else {
        initialSelections[group.id] = [];
      }
    });
    setSelections(initialSelections);
  }, [item]);

  const toggleOption = (group: CustomizationGroup, option: Modifier) => {
    setSelections(prev => {
      const currentGroupSelections = prev[group.id] || [];
      const isSelected = currentGroupSelections.includes(option.id);

      if (group.type === 'single') {
        return { ...prev, [group.id]: [option.id] };
      } else {
        if (isSelected) {
          return { ...prev, [group.id]: currentGroupSelections.filter(id => id !== option.id) };
        } else {
          if (group.maxSelection && currentGroupSelections.length >= group.maxSelection) {
            return prev;
          }
          return { ...prev, [group.id]: [...currentGroupSelections, option.id] };
        }
      }
    });
  };

  const calculateTotal = () => {
    let base = selectedVariant ? selectedVariant.price : item.price;
    item.customizationGroups?.forEach(group => {
      const selectedIds = selections[group.id] || [];
      selectedIds.forEach(id => {
        const option = group.options.find(o => o.id === id);
        if (option) {
          base += option.price;
        }
      });
    });
    return base * quantity;
  };

  const collectModifiers = () => {
    const allModifiers: SelectedModifier[] = [];
    item.customizationGroups?.forEach(group => {
       const selectedIds = selections[group.id] || [];
       selectedIds.forEach(id => {
         const option = group.options.find(o => o.id === id);
         if (option) {
            allModifiers.push({
              groupName: group.name,
              optionName: option.name,
              price: option.price
            });
         }
       });
    });
    return allModifiers;
  };

  const handleAdd = () => {
    onAddToCart(item, quantity, selectedVariant, collectModifiers(), itemNote.trim());
    onClose();
  };

  const handleSaveFavorite = async () => {
      if (!currentUser) return;
      const name = prompt("Name your creation (e.g. 'My Morning Burger'):");
      if (!name) return;

      const mods = collectModifiers();
      await saveUserFavorite(currentUser.phoneNumber, {
          id: Math.random().toString(36).substr(2, 9),
          name,
          baseItemId: item.id,
          selectedVariant,
          selectedModifiers: mods,
          itemNote
      });
      setIsFavoriteSaved(true);
      setTimeout(() => setIsFavoriteSaved(false), 3000);
  };

  const currentTotal = calculateTotal();
  // Use variant image if available, otherwise item image
  const displayImage = selectedVariant?.image || item.image;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header Image - High Resolution Area */}
        <div className="relative h-56 md:h-80 shrink-0 bg-gray-100 overflow-hidden group">
          <img 
            src={displayImage} 
            alt={item.name}
            referrerPolicy="no-referrer"
            onError={(e) => (e.target as HTMLImageElement).src = `https://placehold.co/600x400?text=${item.name}`}
            className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
          />
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition z-10"
          >
            <X size={20} />
          </button>
          
          {currentUser && (
             <button 
                onClick={handleSaveFavorite}
                className={`absolute top-4 left-4 p-2 rounded-full transition flex items-center gap-2 text-xs font-bold z-10 shadow-lg ${isFavoriteSaved ? 'bg-green-500 text-white' : 'bg-white/90 text-primary hover:bg-white'}`}
             >
                {isFavoriteSaved ? <Check size={16} /> : <Heart size={16} className="fill-current" />}
                {isFavoriteSaved ? 'Saved!' : 'Save Favorite'}
             </button>
          )}

          <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/90 via-black/40 to-transparent p-6 pt-20">
             <h2 className="text-3xl font-bold text-white leading-tight drop-shadow-md">{item.name}</h2>
             <p className="text-white/90 text-sm mt-1 line-clamp-2 drop-shadow-sm font-medium">{item.description}</p>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-8 bg-gray-50/50">
          
          {item.variants && item.variants.length > 0 && (
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-3 flex items-center gap-2">
                  Select Size
                  {selectedVariant && selectedVariant.image && <span className="text-xs font-normal text-gray-500 bg-gray-200 px-2 py-0.5 rounded-full">Image Updated</span>}
              </h3>
              <div className="space-y-2">
                {item.variants.map(variant => (
                  <label 
                    key={variant.id} 
                    className={`flex items-center justify-between p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedVariant?.id === variant.id 
                        ? 'border-primary bg-white ring-2 ring-primary shadow-md' 
                        : 'border-gray-200 bg-white hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                         selectedVariant?.id === variant.id ? 'border-primary' : 'border-gray-300'
                      }`}>
                         {selectedVariant?.id === variant.id && <div className="w-2.5 h-2.5 rounded-full bg-primary" />}
                      </div>
                      <span className={`font-bold ${selectedVariant?.id === variant.id ? 'text-gray-900' : 'text-gray-600'}`}>
                        {variant.name}
                      </span>
                    </div>
                    <span className="font-bold text-gray-900">${variant.price.toFixed(2)}</span>
                    <input 
                      type="radio" 
                      name="variant" 
                      className="hidden" 
                      checked={selectedVariant?.id === variant.id}
                      onChange={() => setSelectedVariant(variant)}
                    />
                  </label>
                ))}
              </div>
            </div>
          )}

          {item.customizationGroups?.map(group => (
             <div key={group.id}>
                <div className="flex justify-between items-baseline mb-3">
                   <h3 className="text-lg font-bold text-gray-900">{group.name}</h3>
                   <span className={`text-xs font-bold uppercase tracking-wider px-2 py-1 rounded ${group.type === 'single' ? 'bg-red-100 text-red-700' : 'bg-gray-200 text-gray-600'}`}>
                     {group.type === 'single' ? 'Required' : 'Optional'}
                   </span>
                </div>
                
                <div className="grid grid-cols-1 gap-2">
                   {group.options.map(option => {
                      const isSelected = (selections[group.id] || []).includes(option.id);
                      return (
                        <label 
                          key={option.id}
                          className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                            isSelected 
                              ? 'border-primary bg-white ring-1 ring-primary shadow-sm' 
                              : 'border-gray-200 bg-white hover:bg-gray-50'
                          }`}
                        >
                           <div className="flex items-center gap-3">
                              {group.type === 'single' ? (
                                <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${isSelected ? 'border-primary' : 'border-gray-300'}`}>
                                   {isSelected && <div className="w-2.5 h-2.5 rounded-full bg-primary" />}
                                </div>
                              ) : (
                                <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${isSelected ? 'bg-primary border-primary text-white' : 'border-gray-300 bg-white'}`}>
                                   {isSelected && <Check size={12} />}
                                </div>
                              )}
                              <span className={`font-medium ${isSelected ? 'text-gray-900' : 'text-gray-700'}`}>
                                {option.name}
                              </span>
                           </div>
                           <span className="text-gray-600 font-medium">
                              {option.price > 0 ? `+ $${option.price.toFixed(2)}` : ''}
                           </span>
                           <input 
                              type={group.type === 'single' ? 'radio' : 'checkbox'}
                              name={group.id}
                              className="hidden"
                              checked={isSelected}
                              onChange={() => toggleOption(group, option)}
                           />
                        </label>
                      );
                   })}
                </div>
             </div>
          ))}

          <div>
            <div className="flex justify-between items-baseline mb-3">
               <h3 className="text-lg font-bold text-gray-900">Special Instructions</h3>
               <span className="text-xs font-bold uppercase tracking-wider text-gray-400">Optional</span>
            </div>
            <div className="relative">
              <textarea 
                value={itemNote}
                onChange={(e) => setItemNote(e.target.value)}
                rows={2}
                placeholder="e.g. No ice, Sauce on side..."
                className="w-full p-3 pl-10 border border-gray-300 rounded-xl outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 resize-none bg-white"
              />
              <MessageSquare size={18} className="absolute top-3 left-3 text-gray-400" />
            </div>
          </div>
        </div>

        <div className="p-6 bg-white border-t border-gray-100 shadow-[0_-5px_15px_rgba(0,0,0,0.05)] z-20">
           <div className="flex items-center justify-between mb-4">
              <span className="text-gray-500 font-bold">Quantity</span>
              <div className="flex items-center gap-4 bg-gray-100 rounded-xl p-1.5">
                 <button 
                   onClick={() => setQuantity(Math.max(1, quantity - 1))}
                   className="w-9 h-9 flex items-center justify-center bg-white rounded-lg shadow-sm text-gray-700 hover:text-primary transition active:scale-95"
                 >
                    <Minus size={18} />
                 </button>
                 <span className="font-black text-xl w-8 text-center">{quantity}</span>
                 <button 
                   onClick={() => setQuantity(quantity + 1)}
                   className="w-9 h-9 flex items-center justify-center bg-white rounded-lg shadow-sm text-gray-700 hover:text-primary transition active:scale-95"
                 >
                    <Plus size={18} />
                 </button>
              </div>
           </div>
           
           <button 
             onClick={handleAdd}
             className="w-full bg-primary text-white py-4 rounded-xl font-black text-lg shadow-lg hover:bg-red-700 transition transform active:scale-[0.98] flex justify-between px-6 items-center"
           >
              <span>Add to Order</span>
              <span>${currentTotal.toFixed(2)}</span>
           </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCustomizer;
