
import React, { useState } from 'react';
import { MenuItem } from '../types';
import { Settings2, ImageOff, Ban, Leaf, WheatOff, AlertTriangle, Milk, Info } from 'lucide-react';

interface MenuCardProps {
  item: MenuItem;
  onAdd: (item: MenuItem) => void;
  onCustomize: (item: MenuItem) => void;
}

const MenuCard: React.FC<MenuCardProps> = ({ item, onAdd, onCustomize }) => {
  const [imgSrc, setImgSrc] = useState(item.image);
  const [hasError, setHasError] = useState(false);

  const handleError = () => {
    if (!hasError) {
      setHasError(true);
      setImgSrc(`https://placehold.co/600x400/e2e8f0/1e293b?text=${encodeURIComponent(item.name)}`);
    }
  };

  const hasOptions = (item.variants && item.variants.length > 0) || (item.customizationGroups && item.customizationGroups.length > 0);

  const handleButtonClick = () => {
    onCustomize(item);
  };

  return (
    <div className={`bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden border flex flex-col h-full ${!item.available ? 'border-gray-200 bg-gray-50 opacity-90' : 'border-gray-100'}`}>
      <div className="relative h-48 overflow-hidden bg-gray-100 flex items-center justify-center">
        <img 
          src={imgSrc} 
          alt={item.name} 
          onError={handleError}
          referrerPolicy="no-referrer"
          className={`w-full h-full object-cover transform transition-transform duration-500 ${!item.available ? 'grayscale opacity-60' : 'hover:scale-105'}`} 
        />
        <div className="absolute inset-0 flex items-center justify-center -z-10 text-gray-300">
            <ImageOff size={32} />
        </div>
        
        {!item.available && (
           <div className="absolute inset-0 bg-black/40 flex items-center justify-center z-10 backdrop-blur-[2px]">
              <span className="bg-red-600 text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-1 shadow-lg border border-red-400">
                 <Ban size={12} /> Unavailable
              </span>
           </div>
        )}

        <div className="absolute top-2 right-2 flex flex-col items-end gap-1 z-10">
           {item.tags.map(tag => (
             <span key={tag} className="bg-black/70 backdrop-blur-sm text-white text-[10px] px-2 py-1 rounded-full uppercase tracking-wider font-semibold">
               {tag}
             </span>
           ))}
        </div>
        
        {/* Dietary Icons */}
        <div className="absolute bottom-2 left-2 flex gap-1 z-10">
           {item.dietaryInfo?.isVegetarian && (
               <div className="bg-green-100 text-green-700 p-1 rounded-full shadow-sm" title="Vegetarian">
                   <Leaf size={14} />
               </div>
           )}
           {item.dietaryInfo?.isVegan && (
               <div className="bg-green-600 text-white p-1 rounded-full shadow-sm" title="Vegan">
                   <Leaf size={14} className="fill-current" />
               </div>
           )}
           {item.dietaryInfo?.isGlutenFree && (
               <div className="bg-yellow-100 text-yellow-700 p-1 rounded-full shadow-sm" title="Gluten Free">
                   <WheatOff size={14} />
               </div>
           )}
        </div>
      </div>
      <div className="p-4 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-2">
          <h3 className={`font-serif font-bold text-lg leading-tight ${!item.available ? 'text-gray-500' : 'text-gray-900'}`}>{item.name}</h3>
          <span className={`font-semibold whitespace-nowrap ml-2 ${!item.available ? 'text-gray-400' : 'text-primary'}`}>
             {hasOptions && item.variants ? `From $${item.variants[0].price}` : `$${item.price}`}
          </span>
        </div>
        
        <p className="text-gray-500 text-sm mb-4 flex-1 line-clamp-3">{item.description}</p>
        
        {/* Allergen Warning Small */}
        {item.dietaryInfo?.allergens && item.dietaryInfo.allergens.length > 0 && (
            <div className="mb-3 flex items-center gap-1 text-[10px] text-gray-400">
                <AlertTriangle size={10} />
                <span>Contains: {item.dietaryInfo.allergens.join(', ')}</span>
            </div>
        )}

        <button 
          onClick={handleButtonClick}
          disabled={!item.available}
          className={`w-full mt-auto font-medium py-2 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2 transform ${
              item.available 
                ? 'bg-gray-100 hover:bg-secondary hover:text-white text-gray-900 active:scale-95' 
                : 'bg-gray-50 text-gray-400 cursor-not-allowed border border-gray-100'
          }`}
        >
          {item.available ? (
             <><Settings2 size={16} /> Customize</>
          ) : (
            <><Ban size={16} /> Currently Unavailable</>
          )}
        </button>
      </div>
    </div>
  );
};

export default MenuCard;
