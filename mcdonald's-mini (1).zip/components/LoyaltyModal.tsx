
import React, { useState, useEffect } from 'react';
import { LoyaltyUser, Reward, Order } from '../types';
import { REWARDS } from '../constants';
import { getLoyaltyAccount, getLastCustomerOrder } from '../services/storageService';
import { X, Gift, LogIn, Award, History, RotateCcw, ArrowRight, LogOut, UserPlus } from 'lucide-react';

interface LoyaltyModalProps {
  isOpen: boolean;
  initialAuthMode?: 'signin' | 'signup';
  onClose: () => void;
  currentUser: LoyaltyUser | null;
  onLogin: (user: LoyaltyUser) => void;
  onLogout: () => void;
  onRedeemReward: (reward: Reward) => void;
  onReorder: (order: Order) => void;
}

const LoyaltyModal: React.FC<LoyaltyModalProps> = ({ isOpen, initialAuthMode = 'signin', onClose, currentUser, onLogin, onLogout, onRedeemReward, onReorder }) => {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>(initialAuthMode);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'rewards' | 'history'>('rewards');
  const [lastOrder, setLastOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (isOpen) {
        setAuthMode(initialAuthMode);
        if (currentUser) {
            getLastCustomerOrder(currentUser.phoneNumber).then(order => {
                setLastOrder(order);
            });
        }
    }
  }, [isOpen, currentUser, initialAuthMode]);

  if (!isOpen) return null;

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length < 10) {
        alert("Please enter a valid phone number");
        return;
    }
    if (authMode === 'signup') {
        if (!name.trim()) {
            alert("Please enter your name");
            return;
        }
        if (!email.trim() || !email.includes('@')) {
            alert("Please enter a valid email address");
            return;
        }
    }
    
    setIsLoading(true);
    // Simulate network delay
    setTimeout(async () => {
        // For 'signup', we pass the extra details. For 'signin', just the phone.
        const user = await getLoyaltyAccount(
            phoneNumber, 
            authMode === 'signup' ? name : undefined, 
            authMode === 'signup' ? email : undefined
        );
        onLogin(user);
        setIsLoading(false);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-accent to-yellow-400 p-6 text-primary relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10 transform rotate-12">
                <Gift size={120} />
            </div>
            
            <button onClick={onClose} className="absolute top-4 right-4 bg-white/20 hover:bg-white/40 p-2 rounded-full text-primary transition">
                <X size={20} />
            </button>

            <div className="relative z-10">
                <h2 className="text-3xl font-black italic tracking-tighter">M Rewards</h2>
                <p className="font-bold opacity-80">Earn points on every order</p>
            </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto bg-gray-50">
            {!currentUser ? (
                // --- Auth View (Login / Signup) ---
                <div className="p-8 flex flex-col h-full justify-center">
                     <div className="text-center mb-6">
                        <div className="w-20 h-20 bg-white rounded-full mx-auto flex items-center justify-center shadow-lg mb-4 text-accent">
                             {authMode === 'signin' ? <LogIn size={40} /> : <UserPlus size={40} />}
                        </div>
                        <h3 className="text-xl font-bold text-gray-900">
                            {authMode === 'signin' ? 'Welcome Back' : 'Create Account'}
                        </h3>
                        <p className="text-gray-500 text-sm mt-2">
                            {authMode === 'signin' 
                                ? 'Enter your mobile number to access your rewards.' 
                                : 'Join now to start earning points immediately!'}
                        </p>
                     </div>
                     
                     <form onSubmit={handleAuth} className="space-y-4">
                        {authMode === 'signup' && (
                            <>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-1">Full Name</label>
                                    <input 
                                        type="text" 
                                        value={name}
                                        onChange={(e) => setName(e.target.value)}
                                        placeholder="John Doe"
                                        className="w-full p-4 border border-gray-300 rounded-xl text-lg focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-1">Email Address (Gmail)</label>
                                    <input 
                                        type="email" 
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        placeholder="you@gmail.com"
                                        className="w-full p-4 border border-gray-300 rounded-xl text-lg focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent"
                                    />
                                </div>
                            </>
                        )}
                        <div>
                            <label className="block text-sm font-bold text-gray-700 mb-1">Mobile Number</label>
                            <input 
                                type="tel" 
                                value={phoneNumber}
                                onChange={(e) => setPhoneNumber(e.target.value)}
                                placeholder="0300 1234567"
                                className="w-full p-4 border border-gray-300 rounded-xl text-lg focus:outline-none focus:ring-2 focus:ring-accent focus:border-accent"
                            />
                        </div>
                        <button 
                            type="submit" 
                            disabled={isLoading}
                            className="w-full bg-primary text-white py-4 rounded-xl font-bold shadow-lg hover:bg-red-700 transition flex items-center justify-center gap-2 disabled:opacity-70"
                        >
                            {isLoading ? 'Processing...' : (
                                authMode === 'signin' 
                                    ? <><LogIn size={20} /> Sign In</> 
                                    : <><UserPlus size={20} /> Create Account</>
                            )}
                        </button>
                     </form>
                     
                     <div className="mt-6 text-center">
                        <button 
                            type="button"
                            onClick={() => setAuthMode(authMode === 'signin' ? 'signup' : 'signin')}
                            className="text-primary font-bold text-sm hover:underline"
                        >
                            {authMode === 'signin' 
                                ? "Don't have an account? Sign Up" 
                                : "Already have an account? Sign In"}
                        </button>
                     </div>
                </div>
            ) : (
                // --- Dashboard View ---
                <div className="p-0">
                    {/* Stats Card */}
                    <div className="bg-white p-6 shadow-sm mb-4 relative">
                        <div className="flex justify-between items-center mb-1">
                            <span className="text-sm font-bold text-gray-500">Available Balance</span>
                            <div className="flex items-center gap-2">
                                <div className="text-right">
                                    <span className="block text-xs font-bold text-gray-900">{currentUser.name || 'Guest'}</span>
                                    <span className="block text-xs font-mono text-gray-400">{currentUser.email || currentUser.phoneNumber}</span>
                                </div>
                                <button onClick={onLogout} className="bg-red-50 p-2 rounded-full text-red-500 hover:bg-red-100 transition" title="Logout">
                                    <LogOut size={16} />
                                </button>
                            </div>
                        </div>
                        <div className="text-4xl font-black text-primary mb-4">
                            {currentUser.points.toLocaleString()} <span className="text-lg font-bold text-gray-400">pts</span>
                        </div>
                        
                        {/* Progress Example */}
                        <div className="bg-gray-100 rounded-full h-2 mb-2 overflow-hidden">
                             <div 
                                className="bg-accent h-full rounded-full" 
                                style={{ width: `${Math.min((currentUser.points % 500) / 500 * 100, 100)}%` }}
                             ></div>
                        </div>
                        <div className="flex justify-between text-xs text-gray-500 font-medium">
                            <span>0</span>
                            <span>Next Reward: 500 pts</span>
                        </div>
                    </div>

                    {/* Reorder Button */}
                    {lastOrder && (
                        <div className="px-4 mb-4">
                            <button 
                                onClick={() => onReorder(lastOrder)}
                                className="w-full bg-white border-2 border-primary/10 hover:border-primary/30 p-4 rounded-xl flex items-center justify-between shadow-sm transition group"
                            >
                                <div className="flex items-center gap-3">
                                    <div className="bg-blue-50 text-blue-600 p-2 rounded-lg group-hover:bg-blue-100 transition">
                                        <RotateCcw size={20} />
                                    </div>
                                    <div className="text-left">
                                        <h4 className="font-bold text-gray-900 text-sm">Reorder Last Meal</h4>
                                        <p className="text-xs text-gray-500">{lastOrder.items.length} items • ${lastOrder.total.toFixed(2)}</p>
                                    </div>
                                </div>
                                <ArrowRight size={18} className="text-gray-400 group-hover:text-primary transition" />
                            </button>
                        </div>
                    )}

                    {/* Tabs */}
                    <div className="flex border-b border-gray-200 bg-white sticky top-0 z-10">
                        <button 
                           onClick={() => setActiveTab('rewards')}
                           className={`flex-1 py-3 text-sm font-bold border-b-2 transition ${activeTab === 'rewards' ? 'border-primary text-primary' : 'border-transparent text-gray-500'}`}
                        >
                            Rewards
                        </button>
                        <button 
                           onClick={() => setActiveTab('history')}
                           className={`flex-1 py-3 text-sm font-bold border-b-2 transition ${activeTab === 'history' ? 'border-primary text-primary' : 'border-transparent text-gray-500'}`}
                        >
                            History
                        </button>
                    </div>

                    {/* Tab Content */}
                    <div className="p-4 space-y-4">
                        {activeTab === 'rewards' ? (
                            <>
                                {REWARDS.map(reward => {
                                    const canRedeem = currentUser.points >= reward.pointCost;
                                    return (
                                        <div key={reward.id} className={`bg-white rounded-xl p-4 border flex items-center gap-4 transition ${canRedeem ? 'border-gray-200 shadow-sm' : 'border-gray-100 opacity-60'}`}>
                                            <div className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 ${canRedeem ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}>
                                                <Gift size={24} />
                                            </div>
                                            <div className="flex-1">
                                                <h4 className="font-bold text-gray-900">{reward.name}</h4>
                                                <p className="text-xs text-gray-500">{reward.description}</p>
                                                <span className="text-xs font-bold text-accent mt-1 block">{reward.pointCost} points</span>
                                            </div>
                                            <button 
                                                onClick={() => onRedeemReward(reward)}
                                                disabled={!canRedeem}
                                                className={`px-4 py-2 rounded-lg font-bold text-sm transition ${
                                                    canRedeem 
                                                    ? 'bg-primary text-white hover:bg-red-700 shadow' 
                                                    : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                                }`}
                                            >
                                                Redeem
                                            </button>
                                        </div>
                                    );
                                })}
                            </>
                        ) : (
                            // History Tab
                            <div className="space-y-4">
                                {currentUser.history.length === 0 ? (
                                    <div className="text-center py-10 text-gray-400">
                                        <History className="mx-auto mb-2 opacity-50" />
                                        <p>No activity yet.</p>
                                    </div>
                                ) : (
                                    currentUser.history.map(item => (
                                        <div key={item.id} className="bg-white p-3 rounded-lg border border-gray-100 flex justify-between items-center">
                                            <div>
                                                <p className="font-bold text-sm text-gray-800">{item.activity}</p>
                                                <p className="text-xs text-gray-400">{new Date(item.date).toLocaleDateString()}</p>
                                            </div>
                                            <span className={`font-mono font-bold ${item.pointsChange > 0 ? 'text-green-600' : 'text-red-500'}`}>
                                                {item.pointsChange > 0 ? '+' : ''}{item.pointsChange}
                                            </span>
                                        </div>
                                    ))
                                )}
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default LoyaltyModal;
